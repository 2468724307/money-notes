import { Receipt } from "lucide-react";
import { Card, EmptyState, PrimaryButton } from "../ui";
import { MonthSwitcher, ProgressBar } from "../chrome";
import { TxRow } from "../tx-row";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen } from "@/lib/ledger/money";
import { formatMonthTitle, shiftMonth } from "@/lib/ledger/dates";
import {
  budgetStatus,
  budgetUsedFen,
  findBudget,
  inMonth,
  monthTotals,
  totalBalanceFen,
} from "@/lib/ledger/formulas";
import { cn } from "@/lib/utils";

export function HomeScreen() {
  const settings = useLedgerStore((s) => s.settings);
  const accounts = useLedgerStore((s) => s.accounts);
  const categories = useLedgerStore((s) => s.categories);
  const transactions = useLedgerStore((s) => s.transactions);
  const budgets = useLedgerStore((s) => s.budgets);
  const month = useNavStore((s) => s.month);
  const setMonth = useNavStore((s) => s.setMonth);
  const push = useNavStore((s) => s.push);
  const setFabOpen = useNavStore((s) => s.setFabOpen);

  const totals = monthTotals(transactions, month);
  const balance = totalBalanceFen(accounts, transactions);
  const recent = transactions.filter((t) => inMonth(t, month)).slice(0, 5);
  const totalBudget = findBudget(budgets, month, null);
  const used = budgetUsedFen(transactions, month, null);
  const tone = totalBudget ? budgetStatus(used, totalBudget.amountFen) : "ok";

  return (
    <div className="flex h-full flex-col">
      <header className="px-5 pb-2 pt-[calc(0.75rem+env(safe-area-inset-top))]">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[13px] text-muted">本地账本</p>
            <h1 className="truncate text-[22px] font-bold tracking-tight">{settings.bookName}</h1>
          </div>
        </div>
        <div className="mt-1">
          <MonthSwitcher
            month={month}
            label={formatMonthTitle(month)}
            onPrev={() => setMonth(shiftMonth(month, -1))}
            onNext={() => setMonth(shiftMonth(month, 1))}
          />
        </div>
      </header>

      <div className="screen-scroll px-4 pb-28">
        <Card className="mt-2 bg-surface p-5">
          <p className="text-[12px] font-medium text-muted">本月结余</p>
          <p
            className={cn(
              "mt-1 text-[32px] font-bold leading-none tracking-tight tabular-nums",
              totals.surplus < 0 ? "text-expense" : "text-foreground",
            )}
          >
            {formatFen(totals.surplus, { sign: true })}
          </p>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-income-soft px-3 py-2.5">
              <p className="text-[11px] text-income">收入</p>
              <p className="mt-0.5 text-[20px] font-semibold tabular-nums text-income">
                {formatFen(totals.income)}
              </p>
            </div>
            <div className="rounded-xl bg-expense-soft px-3 py-2.5">
              <p className="text-[11px] text-expense">支出</p>
              <p className="mt-0.5 text-[20px] font-semibold tabular-nums text-expense">
                {formatFen(totals.expense)}
              </p>
            </div>
          </div>
          <p className="mt-3 text-[12px] text-muted">
            全部账户余额 {formatFen(balance)}
            <button
              type="button"
              className="ml-2 text-primary"
              onClick={() => push({ name: "accounts" })}
            >
              查看账户
            </button>
          </p>
        </Card>

        {totalBudget ? (
          <button
            type="button"
            onClick={() => push({ name: "budget" })}
            className="hairline mt-3 w-full rounded-2xl bg-surface p-4 text-left"
          >
            <div className="mb-2 flex items-center justify-between text-[13px]">
              <span className="font-medium">本月预算</span>
              <span className="tabular-nums text-muted">
                已用 {formatFen(used)} / {formatFen(totalBudget.amountFen)}
              </span>
            </div>
            <ProgressBar ratio={totalBudget.amountFen ? used / totalBudget.amountFen : 0} tone={tone} />
            <p className="mt-2 text-[12px] text-muted">
              {tone === "over"
                ? "已超出预算，仅作提示。"
                : tone === "warn"
                  ? "已使用 80% 以上。"
                  : `剩余 ${formatFen(totalBudget.amountFen - used)}`}
            </p>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => push({ name: "budget" })}
            className="mt-3 w-full rounded-2xl bg-primary-soft px-4 py-3 text-left text-[13px] text-primary"
          >
            还没有预算，点这里设一个本月上限
          </button>
        )}

        <div className="mt-5 flex items-center justify-between px-1">
          <h2 className="text-[15px] font-semibold">最近账单</h2>
          <button type="button" className="text-[13px] text-primary" onClick={() => useNavStore.getState().goTab("bills")}>
            全部
          </button>
        </div>

        {recent.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="还没有账单"
            body="记一笔支出或收入，首页、统计和预算会一起更新。"
            action={
              <PrimaryButton tone="expense" onClick={() => setFabOpen(true)}>
                开始记账
              </PrimaryButton>
            }
          />
        ) : (
          <div className="hairline mt-2 overflow-hidden rounded-2xl bg-surface">
            {recent.map((tx) => (
              <TxRow
                key={tx.id}
                tx={tx}
                accounts={accounts}
                categories={categories}
                onClick={() => push({ name: "detail", id: tx.id })}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
