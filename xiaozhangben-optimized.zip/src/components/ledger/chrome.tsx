import type { ReactNode } from "react";
import {
  BarChart3,
  BookOpen,
  Home,
  Plus,
  ArrowLeftRight,
  Minus,
  UserRound,
  X,
} from "lucide-react";
import { useNavStore, type TabName } from "@/lib/ledger/nav";
import { useConfirmStore } from "@/lib/ledger/confirm";
import { cn } from "@/lib/utils";

const TABS: { id: TabName; label: string; icon: typeof Home }[] = [
  { id: "home", label: "首页", icon: Home },
  { id: "bills", label: "账单", icon: BookOpen },
  { id: "stats", label: "统计", icon: BarChart3 },
  { id: "me", label: "我的", icon: UserRound },
];

export function BottomNav() {
  const tab = useNavStore((s) => s.tab);
  const goTab = useNavStore((s) => s.goTab);
  return (
    <nav
      className="shrink-0 border-t border-divider bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md"
      style={{ height: "calc(64px + env(safe-area-inset-bottom))" }}
    >
      <div className="grid h-16 grid-cols-4">
        {TABS.map((t) => {
          const active = tab === t.id;
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => goTab(t.id)}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                active ? "text-primary" : "text-muted",
              )}
            >
              <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
              {t.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function RecordFab() {
  const open = useNavStore((s) => s.fabOpen);
  const setOpen = useNavStore((s) => s.setFabOpen);
  const push = useNavStore((s) => s.push);

  return (
    <>
      {open ? (
        <button
          type="button"
          aria-label="关闭"
          className="absolute inset-0 z-30 bg-foreground/20"
          onClick={() => setOpen(false)}
        />
      ) : null}
      <div className="pointer-events-none absolute inset-x-0 bottom-[calc(72px+env(safe-area-inset-bottom))] z-40 flex flex-col items-end px-5">
        {open ? (
          <div className="pointer-events-auto mb-3 flex flex-col items-end gap-2">
            <FabAction
              label="转账"
              className="bg-primary text-primary-foreground"
              icon={<ArrowLeftRight className="size-4" />}
              onClick={() => push({ name: "record", type: "TRANSFER" })}
            />
            <FabAction
              label="收入"
              className="bg-income text-primary-foreground"
              icon={<Plus className="size-4" />}
              onClick={() => push({ name: "record", type: "INCOME" })}
            />
            <FabAction
              label="支出"
              className="bg-expense text-primary-foreground"
              icon={<Minus className="size-4" />}
              onClick={() => push({ name: "record", type: "EXPENSE" })}
            />
          </div>
        ) : null}
        <button
          type="button"
          aria-label={open ? "关闭记账" : "记一笔"}
          onClick={() => setOpen(!open)}
          className={cn(
            "pointer-events-auto flex size-14 items-center justify-center rounded-full text-primary-foreground shadow-[var(--shadow-float)] transition-transform duration-200",
            open ? "bg-foreground" : "bg-primary",
          )}
        >
          {open ? <X className="size-6" /> : <Plus className="size-7" strokeWidth={2.2} />}
        </button>
      </div>
    </>
  );
}

function FabAction({
  label,
  className,
  icon,
  onClick,
}: {
  label: string;
  className: string;
  icon: ReactNode;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="flex items-center gap-2">
      <span className="text-[13px] font-medium text-foreground">{label}</span>
      <span className={cn("flex size-11 items-center justify-center rounded-full", className)}>
        {icon}
      </span>
    </button>
  );
}

export function ConfirmHost() {
  const s = useConfirmStore();
  if (!s.open) return null;
  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:items-center">
      <div className="w-full max-w-sm rounded-2xl bg-surface p-5 shadow-[var(--shadow-card)]">
        <h2 className="text-[17px] font-semibold">{s.title}</h2>
        <p className="mt-2 text-[14px] leading-relaxed text-muted">{s.body}</p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => s.close(false)}
            className="h-11 rounded-xl bg-surface-2 text-[14px] font-medium"
          >
            {s.cancelLabel}
          </button>
          <button
            type="button"
            onClick={() => s.close(true)}
            className={cn(
              "h-11 rounded-xl text-[14px] font-semibold text-primary-foreground",
              s.danger ? "bg-expense" : "bg-primary",
            )}
          >
            {s.confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

export function MonthSwitcher({
  month,
  onPrev,
  onNext,
  label,
}: {
  month: string;
  onPrev: () => void;
  onNext: () => void;
  label: string;
}) {
  return (
    <div className="flex items-center justify-center gap-2">
      <button
        type="button"
        aria-label="上月"
        onClick={onPrev}
        className="flex size-9 items-center justify-center rounded-lg text-muted"
      >
        <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M15 6l-6 6 6 6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      <span className="min-w-[7.5rem] text-center text-[15px] font-semibold tabular-nums">{label}</span>
      <button
        type="button"
        aria-label="下月"
        onClick={onNext}
        className="flex size-9 items-center justify-center rounded-lg text-muted"
      >
        <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
    </div>
  );
}

export function ProgressBar({
  ratio,
  tone,
}: {
  ratio: number;
  tone: "ok" | "warn" | "over";
}) {
  const width = Math.min(100, Math.max(0, ratio * 100));
  const color =
    tone === "over" ? "bg-expense" : tone === "warn" ? "bg-warning" : "bg-primary";
  return (
    <div className="progress-track">
      <div className={cn("progress-fill", color)} style={{ width: `${width}%` }} />
    </div>
  );
}
