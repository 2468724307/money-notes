import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.xiaozhangben.app",
  appName: "小账本",
  webDir: "capacitor-web",
  bundledWebRuntime: false,
  server: {
    androidScheme: "https",
  },
};

export default config;
