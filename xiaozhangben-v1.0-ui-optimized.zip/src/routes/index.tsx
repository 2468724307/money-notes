import { createFileRoute } from "@tanstack/react-router";
import { LedgerApp } from "@/components/ledger/app-root";

export const Route = createFileRoute("/")({
  ssr: false,
  component: LedgerApp,
});
