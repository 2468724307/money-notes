import type { HTMLAttributes, ReactNode } from "react";
import { ChevronLeft, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function TopBar({
  title,
  onBack,
  right,
  subtitle,
}: {
  title: string;
  onBack?: () => void;
  right?: ReactNode;
  subtitle?: string;
}) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-1 px-3 pt-[env(safe-area-inset-top)]">
      {onBack ? (
        <button
          type="button"
          aria-label="返回"
          onClick={onBack}
          className="flex size-11 items-center justify-center rounded-xl text-foreground"
        >
          <ChevronLeft className="size-6" strokeWidth={1.8} />
        </button>
      ) : (
        <span className="w-2" />
      )}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-[17px] font-semibold leading-tight tracking-tight">{title}</h1>
        {subtitle ? <p className="truncate text-xs text-muted">{subtitle}</p> : null}
      </div>
      <div className="flex min-w-11 items-center justify-end pr-1">{right}</div>
    </header>
  );
}

export function Card({
  children,
  className,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  const cls = cn("hairline rounded-[20px] bg-surface p-4", className);
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={cn(cls, "w-full text-left")}>
        {children}
      </button>
    );
  }
  return <div className={cls}>{children}</div>;
}

export function PrimaryButton({
  children,
  disabled,
  onClick,
  className,
  tone = "primary",
}: {
  children: ReactNode;
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
  tone?: "primary" | "expense" | "income";
}) {
  const tones = {
    primary: "bg-primary text-primary-foreground",
    expense: "bg-expense text-primary-foreground",
    income: "bg-income text-primary-foreground",
  };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "h-12 w-full rounded-2xl text-[15px] font-semibold tracking-wide shadow-sm transition-all duration-150 active:scale-[0.985] disabled:opacity-40",
        tones[tone],
        className,
      )}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  onClick,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-12 w-full rounded-2xl bg-surface-2 text-[15px] font-medium text-foreground",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

export function TextField({
  value,
  onChange,
  placeholder,
  inputMode,
  type = "text",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  inputMode?: HTMLAttributes<HTMLInputElement>["inputMode"];
  type?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      inputMode={inputMode}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      className="h-12 w-full rounded-xl bg-surface-2 px-3.5 text-[15px] text-foreground outline-none ring-ring placeholder:text-subtle focus:ring-2"
    />
  );
}

export function Chip({
  active,
  children,
  onClick,
}: {
  active?: boolean;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full px-3.5 text-[13px] font-medium transition-colors",
        active ? "bg-primary text-primary-foreground" : "bg-surface-2 text-muted",
      )}
    >
      {children}
    </button>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  body,
  action,
}: {
  icon: LucideIcon;
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center px-8 py-16 text-center">
      <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary-soft text-primary">
        <Icon className="size-7" strokeWidth={1.7} />
      </div>
      <h2 className="text-base font-semibold">{title}</h2>
      <p className="mt-1.5 max-w-[260px] text-[13px] leading-relaxed text-muted">{body}</p>
      {action ? <div className="mt-5 w-full max-w-[220px]">{action}</div> : null}
    </div>
  );
}

export function Row({
  icon: Icon,
  title,
  hint,
  onClick,
  danger,
}: {
  icon: LucideIcon;
  title: string;
  hint?: string;
  onClick?: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex min-h-[60px] w-full items-center gap-3 px-4 text-left transition-colors active:bg-surface-2/70"
    >
      <span
        className={cn(
          "flex size-9 items-center justify-center rounded-xl",
          danger ? "bg-expense-soft text-expense" : "bg-surface-2 text-foreground",
        )}
      >
        <Icon className="size-4" strokeWidth={1.8} />
      </span>
      <span className="min-w-0 flex-1">
        <span className={cn("block text-[15px]", danger ? "text-expense" : "text-foreground")}>
          {title}
        </span>
        {hint ? <span className="block text-xs text-muted">{hint}</span> : null}
      </span>
      <ChevronRightMuted />
    </button>
  );
}

function ChevronRightMuted() {
  return (
    <svg viewBox="0 0 24 24" className="size-4 text-subtle" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="px-4 pb-2 pt-5 text-xs font-medium tracking-wide text-muted">{children}</p>;
}
