import { ArrowLeftRight } from "lucide-react";
import { categoryIcon, ACCOUNT_ICONS } from "@/lib/ledger/icons";
import { formatFen } from "@/lib/ledger/money";
import { formatDateTime } from "@/lib/ledger/dates";
import type { Account, Category, Transaction } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

export function TxRow({
  tx,
  accounts,
  categories,
  onClick,
  showTime,
}: {
  tx: Transaction;
  accounts: Account[];
  categories: Category[];
  onClick?: () => void;
  showTime?: boolean;
}) {
  const cat = categories.find((c) => c.id === tx.categoryId);
  const acc = accounts.find((a) => a.id === tx.accountId);
  const from = accounts.find((a) => a.id === tx.fromAccountId);
  const to = accounts.find((a) => a.id === tx.toAccountId);
  const Icon = tx.type === "TRANSFER" ? ArrowLeftRight : categoryIcon(cat?.icon ?? "more");
  const title = tx.type === "TRANSFER" ? "转账" : (cat?.name ?? "未分类");
  const sub =
    tx.type === "TRANSFER"
      ? `${from?.name ?? "账户"} → ${to?.name ?? "账户"}`
      : [acc?.name, tx.note].filter(Boolean).join(" · ");
  const tone =
    tx.type === "INCOME"
      ? "text-income"
      : tx.type === "EXPENSE"
        ? "text-expense"
        : "text-foreground";
  const signed =
    tx.type === "TRANSFER"
      ? formatFen(tx.amountFen)
      : formatFen(tx.type === "EXPENSE" ? -tx.amountFen : tx.amountFen, { sign: true });

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex min-h-14 w-full items-center gap-3 px-4 py-2 text-left"
    >
      <span
        className={cn(
          "flex size-10 shrink-0 items-center justify-center rounded-xl",
          tx.type === "INCOME"
            ? "bg-income-soft text-income"
            : tx.type === "EXPENSE"
              ? "bg-expense-soft text-expense"
              : "bg-primary-soft text-primary",
        )}
      >
        <Icon className="size-4" strokeWidth={1.8} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center justify-between gap-2">
          <span className="truncate text-[15px] font-medium">{title}</span>
          <span className={cn("shrink-0 text-[15px] font-semibold tabular-nums", tone)}>
            {signed}
          </span>
        </span>
        <span className="mt-0.5 flex items-center justify-between gap-2 text-xs text-muted">
          <span className="truncate">{sub || "无备注"}</span>
          {showTime ? (
            <span className="shrink-0">{formatDateTime(tx.occurredAt).slice(11)}</span>
          ) : null}
        </span>
      </span>
    </button>
  );
}

export function AccountGlyph({ type }: { type: Account["type"] }) {
  const Icon = ACCOUNT_ICONS[type];
  return <Icon className="size-4" strokeWidth={1.8} />;
}
