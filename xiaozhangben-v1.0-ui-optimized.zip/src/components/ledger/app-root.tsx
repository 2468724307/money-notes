import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { useLedgerStore } from "@/lib/ledger/store";
import { isTabScreen, useNavStore, type Screen } from "@/lib/ledger/nav";
import { applyTheme } from "./theme";
import { BottomNav, ConfirmHost, RecordFab } from "./chrome";
import { WelcomeScreen } from "./screens/welcome";
import { SetupScreen } from "./screens/setup";
import { HomeScreen } from "./screens/home";
import { RecordScreen } from "./screens/record";
import { BillsScreen } from "./screens/bills";
import { DetailScreen } from "./screens/detail";
import { FilterScreen } from "./screens/filter";
import { CategoriesScreen } from "./screens/categories";
import { StatsScreen } from "./screens/stats";
import { AnalysisScreen } from "./screens/analysis";
import { BudgetEditScreen, BudgetScreen } from "./screens/budget";
import { AccountEditScreen, AccountsScreen } from "./screens/accounts";
import { MeScreen } from "./screens/me";
import { DataScreen, ImportPreviewScreen, RestorePreviewScreen } from "./screens/data";
import { AboutScreen, AppearanceScreen } from "./screens/settings-extra";
import { LogoMark } from "./screens/welcome";

export function LedgerApp() {
  const [ready, setReady] = useState(false);
  const onboarded = useLedgerStore((s) => s.settings.onboardingComplete);
  const stack = useNavStore((s) => s.stack);
  const tab = useNavStore((s) => s.tab);
  const raw: Screen = stack.at(-1) ?? { name: tab };

  useEffect(() => {
    const finish = () => {
      applyTheme(useLedgerStore.getState().settings.theme);
      setReady(true);
    };
    const unsub = useLedgerStore.persist.onFinishHydration(finish);
    void useLedgerStore.persist.rehydrate();
    if (useLedgerStore.persist.hasHydrated()) finish();
    // 允许浏览器在可用时提高本地账本存储的持久性；失败不影响使用。
    if (typeof navigator !== "undefined" && "storage" in navigator) {
      void navigator.storage?.persist?.().catch(() => undefined);
    }
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => undefined);
    }
    return unsub;
  }, []);

  useEffect(() => {
    if (!ready) return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (useLedgerStore.getState().settings.theme === "system") applyTheme("system");
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [ready]);

  const screen: Screen =
    !onboarded && raw.name !== "welcome" && raw.name !== "setup" ? { name: "welcome" } : raw;
  const tabRoot = isTabScreen(screen);

  return (
    <div className="app-shell">
      <div className="app-phone">
        {!ready ? (
          <Splash />
        ) : (
          <>
            <div key={`${screen.name}-${stack.length}`} className="screen-stage overflow-hidden">
              <ScreenView screen={screen} />
            </div>
            {tabRoot && onboarded ? <BottomNav /> : null}
            {tabRoot && onboarded ? <RecordFab /> : null}
            <ConfirmHost />
            <Toaster
              position="top-center"
              duration={1800}
              toastOptions={{
                className:
                  "!bg-surface !text-foreground !border-divider !shadow-[var(--shadow-card)]",
              }}
            />
          </>
        )}
      </div>
    </div>
  );
}

function Splash() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4">
      <LogoMark />
      <p className="text-[15px] font-semibold">小账本</p>
      <p className="text-[12px] text-muted">正在打开本地账本</p>
    </div>
  );
}

function ScreenView({ screen }: { screen: Screen }) {
  switch (screen.name) {
    case "welcome":
      return <WelcomeScreen />;
    case "setup":
      return <SetupScreen />;
    case "home":
      return <HomeScreen />;
    case "bills":
      return <BillsScreen />;
    case "stats":
      return <StatsScreen />;
    case "me":
      return <MeScreen />;
    case "record":
      return <RecordScreen type={screen.type} editId={screen.editId} />;
    case "categories":
      return <CategoriesScreen kind={screen.kind} pick={screen.pick} />;
    case "detail":
      return <DetailScreen id={screen.id} />;
    case "filter":
      return <FilterScreen />;
    case "analysis":
      return <AnalysisScreen categoryId={screen.categoryId} />;
    case "budget":
      return <BudgetScreen />;
    case "budget-edit":
      return <BudgetEditScreen categoryId={screen.categoryId} />;
    case "accounts":
      return <AccountsScreen />;
    case "account-edit":
      return <AccountEditScreen id={screen.id} />;
    case "data":
      return <DataScreen />;
    case "import-preview":
      return <ImportPreviewScreen />;
    case "restore-preview":
      return <RestorePreviewScreen />;
    case "appearance":
      return <AppearanceScreen />;
    case "about":
      return <AboutScreen />;
  }
}
