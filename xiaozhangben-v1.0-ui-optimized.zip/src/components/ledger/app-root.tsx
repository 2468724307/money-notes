import { useEffect, useState } from "react";
import { App } from "@capacitor/app";
import { Capacitor } from "@capacitor/core";
import { Toaster, toast } from "sonner";
import { useLedgerStore } from "@/lib/ledger/store";
import { isTabScreen, useNavStore, type Screen } from "@/lib/ledger/nav";
import { useConfirmStore } from "@/lib/ledger/confirm";
import { applyTheme } from "./theme";
import { BottomNav, ConfirmHost, RecordSheet } from "./chrome";
import { WelcomeScreen } from "./screens/welcome";
import { SetupScreen } from "./screens/setup";
import { HomeScreen } from "./screens/home";
import { RecordScreen } from "./screens/record";
import { BillsScreen } from "./screens/bills";
import { DetailScreen } from "./screens/detail";
import { FilterScreen } from "./screens/filter";
import { CategoriesScreen } from "./screens/categories";
import { StatsScreen } from "./screens/stats";
import { AnalysisScreen } from "./screens/analysis";
import { BudgetEditScreen, BudgetScreen } from "./screens/budget";
import { AccountEditScreen, AccountsScreen } from "./screens/accounts";
import { MeScreen } from "./screens/me";
import { DataScreen, ImportPreviewScreen, RestorePreviewScreen } from "./screens/data";
import { AboutScreen, AppearanceScreen } from "./screens/settings-extra";
import { LogoMark } from "./screens/welcome";

export function LedgerApp() {
  const [ready, setReady] = useState(false);
  const onboarded = useLedgerStore((s) => s.settings.onboardingComplete);
  const stack = useNavStore((s) => s.stack);
  const tab = useNavStore((s) => s.tab);
  const transition = useNavStore((s) => s.transition);
  const raw: Screen = stack.at(-1) ?? { name: tab };

  useEffect(() => {
    const finish = () => {
      applyTheme(useLedgerStore.getState().settings.theme);
      setReady(true);
    };
    const unsub = useLedgerStore.persist.onFinishHydration(finish);
    void useLedgerStore.persist.rehydrate();
    if (useLedgerStore.persist.hasHydrated()) finish();
    // 允许浏览器在可用时提高本地账本存储的持久性；失败不影响使用。
    if (typeof navigator !== "undefined" && "storage" in navigator) {
      void navigator.storage?.persist?.().catch(() => undefined);
    }
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => undefined);
    }
    return unsub;
  }, []);

  useEffect(() => {
    if (!ready) return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (useLedgerStore.getState().settings.theme === "system") applyTheme("system");
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [ready]);

  useEffect(() => {
    const onPopState = () => {
      const nav = useNavStore.getState();
      if (nav.fabOpen) {
        nav.setFabOpen(false);
        return;
      }
      nav.popFromHistory();
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    let removed = false;
    let removeListener: (() => Promise<void>) | undefined;
    let lastExitRequestAt = 0;

    void App.addListener("backButton", () => {
      const confirm = useConfirmStore.getState();
      if (confirm.open) {
        confirm.close(false);
        return;
      }

      const nav = useNavStore.getState();
      if (nav.fabOpen) {
        nav.setFabOpen(false);
        return;
      }

      if (nav.stack.length > 0) {
        // Android 的返回事件已被原生监听器消费，直接同步应用导航栈，
        // 避免再次调用 history.back() 导致 WebView 退出 Activity。
        nav.popFromHistory();
        return;
      }

      if (nav.tab !== "home") {
        nav.goTab("home");
        return;
      }

      const now = Date.now();
      if (now - lastExitRequestAt <= 2000) {
        void App.exitApp();
        return;
      }

      lastExitRequestAt = now;
      toast("再按一次返回键退出小账本", { duration: 1800 });
    })
      .then((handle) => {
        if (removed) void handle.remove();
        else removeListener = () => handle.remove();
      })
      .catch(() => undefined);

    return () => {
      removed = true;
      void removeListener?.();
    };
  }, []);

  const screen: Screen =
    !onboarded && raw.name !== "welcome" && raw.name !== "setup" ? { name: "welcome" } : raw;
  const sheetScreen = screen.name === "filter" ? screen : null;
  const visibleScreen: Screen = sheetScreen ? { name: tab } : screen;
  const tabRoot = isTabScreen(visibleScreen);

  return (
    <div className="app-shell">
      <div className="app-phone">
        {!ready ? (
          <Splash />
        ) : (
          <>
            <div
              key={`${visibleScreen.name}-${stack.length}-${sheetScreen ? "sheet" : "page"}`}
              className={`screen-stage screen-${transition} overflow-hidden`}
            >
              <ScreenView screen={visibleScreen} />
            </div>
            {tabRoot && onboarded ? <BottomNav /> : null}
            {tabRoot && onboarded ? <RecordSheet /> : null}
            {sheetScreen ? (
              <div
                className="sheet-backdrop absolute inset-0 z-40 flex items-end bg-foreground/20 backdrop-blur-[2px]"
                onClick={() => useNavStore.getState().pop()}
              >
                <section
                  className="system-sheet sheet-panel flex max-h-[92%] min-h-[72%] w-full flex-col overflow-hidden rounded-t-[28px]"
                  onClick={(event) => event.stopPropagation()}
                >
                  <span className="sheet-grabber" aria-hidden="true" />
                  <ScreenView screen={sheetScreen} />
                </section>
              </div>
            ) : null}
            <ConfirmHost />
            <Toaster
              position="top-center"
              duration={1800}
              toastOptions={{
                className:
                  "!bg-surface !text-foreground !border-divider !shadow-[var(--shadow-card)]",
              }}
            />
          </>
        )}
      </div>
    </div>
  );
}

function Splash() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4">
      <LogoMark />
      <p className="text-[15px] font-semibold">小账本</p>
      <p className="text-[12px] text-muted">正在打开本地账本</p>
    </div>
  );
}

function ScreenView({ screen }: { screen: Screen }) {
  switch (screen.name) {
    case "welcome":
      return <WelcomeScreen />;
    case "setup":
      return <SetupScreen />;
    case "home":
      return <HomeScreen />;
    case "bills":
      return <BillsScreen />;
    case "stats":
      return <StatsScreen />;
    case "me":
      return <MeScreen />;
    case "record":
      return <RecordScreen type={screen.type} editId={screen.editId} />;
    case "categories":
      return <CategoriesScreen kind={screen.kind} pick={screen.pick} />;
    case "detail":
      return <DetailScreen id={screen.id} />;
    case "filter":
      return <FilterScreen />;
    case "analysis":
      return <AnalysisScreen categoryId={screen.categoryId} />;
    case "budget":
      return <BudgetScreen />;
    case "budget-edit":
      return <BudgetEditScreen categoryId={screen.categoryId} />;
    case "accounts":
      return <AccountsScreen />;
    case "account-edit":
      return <AccountEditScreen id={screen.id} />;
    case "data":
      return <DataScreen />;
    case "import-preview":
      return <ImportPreviewScreen />;
    case "restore-preview":
      return <RestorePreviewScreen />;
    case "appearance":
      return <AppearanceScreen />;
    case "about":
      return <AboutScreen />;
  }
}
