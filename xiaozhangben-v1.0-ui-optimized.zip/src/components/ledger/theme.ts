import type { ThemeMode } from "@/lib/ledger/types";

export function applyTheme(mode: ThemeMode) {
  if (typeof document === "undefined") return;
  const dark =
    mode === "dark" ||
    (mode === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
  const themeColor = dark ? "#0B1220" : "#2C83FD";
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", themeColor);
}
