import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Field, PrimaryButton, TextField, TopBar } from "../ui";
import { MonthSwitcher, ProgressBar } from "../chrome";
import { confirmAction } from "@/lib/ledger/confirm";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen, parseYuanInputToFen, fenToInput } from "@/lib/ledger/money";
import { formatMonthTitle, shiftMonth } from "@/lib/ledger/dates";
import { budgetStatus, budgetUsedFen, findBudget } from "@/lib/ledger/formulas";
import { categoryIcon } from "@/lib/ledger/icons";
import { cn } from "@/lib/utils";

export function BudgetScreen() {
  const pop = useNavStore((s) => s.pop);
  const month = useNavStore((s) => s.month);
  const setMonth = useNavStore((s) => s.setMonth);
  const push = useNavStore((s) => s.push);
  const budgets = useLedgerStore((s) => s.budgets);
  const transactions = useLedgerStore((s) => s.transactions);
  const categories = useLedgerStore((s) => s.categories);
  const total = findBudget(budgets, month, null);
  const usedTotal = budgetUsedFen(transactions, month, null);
  const tone = total ? budgetStatus(usedTotal, total.amountFen) : "ok";
  const catBudgets = budgets.filter(
    (b) => b.month === month && b.categoryId && b.status === "ACTIVE",
  );

  return (
    <div className="flex h-full flex-col">
      <TopBar
        title="预算"
        onBack={pop}
        right={
          <button
            type="button"
            aria-label="新增分类预算"
            className="flex size-11 items-center justify-center"
            onClick={() => push({ name: "budget-edit", categoryId: "new" })}
          >
            <Plus className="size-5" />
          </button>
        }
      />
      <div className="px-4">
        <MonthSwitcher
          month={month}
          label={formatMonthTitle(month)}
          onPrev={() => setMonth(shiftMonth(month, -1))}
          onNext={() => setMonth(shiftMonth(month, 1))}
        />
      </div>
      <div className="screen-scroll px-4 pb-8">
        <button
          type="button"
          onClick={() => push({ name: "budget-edit", categoryId: null })}
          className="mt-3 w-full rounded-2xl bg-surface p-4 text-left hairline"
        >
          <p className="text-[13px] text-muted">本月总预算</p>
          <p className="mt-1 text-[24px] font-bold tabular-nums">
            {total ? formatFen(total.amountFen) : "未设置"}
          </p>
          {total ? (
            <>
              <div className="mt-3 flex justify-between text-[12px] text-muted">
                <span>已用 {formatFen(usedTotal)}</span>
                <span
                  className={cn(
                    tone === "over" ? "text-expense" : tone === "warn" ? "text-warning" : "",
                  )}
                >
                  剩余 {formatFen(total.amountFen - usedTotal)}
                </span>
              </div>
              <div className="mt-2">
                <ProgressBar
                  ratio={total.amountFen ? usedTotal / total.amountFen : 0}
                  tone={tone}
                />
              </div>
              <p className="mt-2 text-[12px] text-muted">
                {tone === "over"
                  ? "已超支，仅为视觉提示。"
                  : tone === "warn"
                    ? "已用 80%–100%。"
                    : "进度正常（低于 80%）。"}
              </p>
            </>
          ) : (
            <p className="mt-2 text-[13px] text-primary">点这里设置总预算</p>
          )}
        </button>

        <h2 className="mt-5 text-[15px] font-semibold">分类预算</h2>
        <div className="mt-2 space-y-2">
          {catBudgets.length === 0 ? (
            <p className="px-1 py-6 text-[13px] text-muted">
              还没有分类预算。只统计支出，收入和转账不消耗预算。
            </p>
          ) : (
            catBudgets.map((b) => {
              const cat = categories.find((c) => c.id === b.categoryId);
              const used = budgetUsedFen(transactions, month, b.categoryId);
              const st = budgetStatus(used, b.amountFen);
              const Icon = categoryIcon(cat?.icon ?? "more");
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => push({ name: "budget-edit", categoryId: b.categoryId })}
                  className="flex w-full items-center gap-3 rounded-2xl bg-surface p-3.5 text-left hairline"
                >
                  <span className="flex size-10 items-center justify-center rounded-xl bg-surface-2 text-foreground">
                    <Icon className="size-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex justify-between text-[14px]">
                      <span className="font-medium">{cat?.name ?? "分类"}</span>
                      <span className="tabular-nums">
                        {formatFen(used)} / {formatFen(b.amountFen)}
                      </span>
                    </span>
                    <span className="mt-2 block">
                      <ProgressBar ratio={b.amountFen ? used / b.amountFen : 0} tone={st} />
                    </span>
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

export function BudgetEditScreen({ categoryId }: { categoryId: string | null }) {
  const pop = useNavStore((s) => s.pop);
  const month = useNavStore((s) => s.month);
  const isNew = categoryId === "new";
  const target = isNew ? null : categoryId;
  const existing = useLedgerStore((s) => findBudget(s.budgets, month, target));
  const categories = useLedgerStore((s) =>
    s.categories.filter((c) => c.type === "EXPENSE" && c.status === "ACTIVE"),
  );
  const upsertBudget = useLedgerStore((s) => s.upsertBudget);
  const deleteBudget = useLedgerStore((s) => s.deleteBudget);
  const [catId, setCatId] = useState<string | null>(target);
  const [amount, setAmount] = useState(existing ? fenToInput(existing.amountFen) : "");

  const title = catId == null && !isNew ? "总预算" : "分类预算";

  return (
    <div className="flex h-full flex-col">
      <TopBar title={title} onBack={pop} />
      <div className="screen-scroll space-y-4 px-4">
        {isNew ? (
          <Field label="分类">
            <select
              value={catId ?? ""}
              onChange={(e) => setCatId(e.target.value)}
              className="h-12 w-full rounded-xl bg-surface-2 px-3 text-[15px]"
            >
              <option value="">请选择</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        <Field label="金额（元）">
          <TextField
            value={amount}
            onChange={(v) => {
              if (v === "" || /^\d*\.?\d{0,2}$/.test(v)) setAmount(v);
            }}
            placeholder="0.00"
            inputMode="decimal"
          />
        </Field>
        <PrimaryButton
          disabled={!parseYuanInputToFen(amount) || (isNew && !catId)}
          onClick={() => {
            upsertBudget({
              month,
              categoryId: isNew ? catId : target,
              amountFen: parseYuanInputToFen(amount),
            });
            toast.success("预算已保存");
            pop();
          }}
        >
          保存
        </PrimaryButton>
        {existing ? (
          <button
            type="button"
            className="flex h-11 w-full items-center justify-center gap-1.5 text-[14px] text-expense"
            onClick={async () => {
              const ok = await confirmAction({
                title: "删除这项预算？",
                body: "只删除预算上限，不会改动任何账单。",
                confirmLabel: "删除",
                danger: true,
              });
              if (!ok) return;
              deleteBudget(existing.id);
              toast.success("已删除预算");
              pop();
            }}
          >
            <Trash2 className="size-4" /> 删除预算
          </button>
        ) : null}
      </div>
    </div>
  );
}
