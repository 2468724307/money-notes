import { BookOpen, Database, Info, Landmark, Palette, PiggyBank, Tags } from "lucide-react";
import { Row, SectionLabel, TopBar } from "../ui";
import { LogoMark } from "./welcome";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen } from "@/lib/ledger/money";
import { totalBalanceFen } from "@/lib/ledger/formulas";

export function MeScreen() {
  const settings = useLedgerStore((s) => s.settings);
  const accounts = useLedgerStore((s) => s.accounts);
  const transactions = useLedgerStore((s) => s.transactions);
  const push = useNavStore((s) => s.push);
  // 停用账户只是禁止新记账，不代表账户余额消失；总资产仍应包含历史账户余额。
  const total = totalBalanceFen(accounts, transactions);
  const themeLabel =
    settings.theme === "dark" ? "深色" : settings.theme === "light" ? "浅色" : "跟随系统";

  return (
    <div className="flex h-full flex-col">
      <TopBar title="我的" />
      <div className="screen-scroll pb-8">
        <div className="mx-4 mt-1 flex items-center gap-3 rounded-2xl bg-surface p-4 hairline">
          <LogoMark size={48} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-[17px] font-semibold">{settings.bookName}</p>
            <p className="mt-0.5 text-[13px] text-muted">总余额 {formatFen(total)}</p>
            <span className="mt-2 inline-flex rounded-full bg-income-soft px-2.5 py-1 text-[11px] font-medium text-income">
              数据只在本机
            </span>
          </div>
        </div>

        <SectionLabel>账本</SectionLabel>
        <div className="mx-4 overflow-hidden rounded-2xl bg-surface hairline">
          <Row
            icon={Landmark}
            title="账户"
            hint="现金 / 银行卡 / 微信 / 支付宝"
            onClick={() => push({ name: "accounts" })}
          />
          <Row
            icon={Tags}
            title="分类"
            hint="支出与收入分开"
            onClick={() => push({ name: "categories", kind: "EXPENSE" })}
          />
          <Row
            icon={PiggyBank}
            title="预算"
            hint="总预算和分类上限"
            onClick={() => push({ name: "budget" })}
          />
          <Row
            icon={BookOpen}
            title="账单"
            hint="搜索和筛选"
            onClick={() => useNavStore.getState().goTab("bills")}
          />
        </div>

        <SectionLabel>数据与外观</SectionLabel>
        <div className="mx-4 overflow-hidden rounded-2xl bg-surface hairline">
          <Row
            icon={Database}
            title="数据管理"
            hint="导出 / 导入 / 备份恢复"
            onClick={() => push({ name: "data" })}
          />
          <Row
            icon={Palette}
            title="外观"
            hint={themeLabel}
            onClick={() => push({ name: "appearance" })}
          />
          <Row
            icon={Info}
            title="关于"
            hint="v2.0 · 手机优化版"
            onClick={() => push({ name: "about" })}
          />
        </div>
      </div>
    </div>
  );
}
