import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Chip, Field, PrimaryButton, TextField, TopBar } from "../ui";
import { confirmAction } from "@/lib/ledger/confirm";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen, parseYuanInputToFen, fenToInput } from "@/lib/ledger/money";
import { ACCOUNT_TYPE_LABEL } from "@/lib/ledger/defaults";
import { accountBalanceFen, totalBalanceFen } from "@/lib/ledger/formulas";
import { ACCOUNT_ICONS } from "@/lib/ledger/icons";
import type { AccountType } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

const TYPES: AccountType[] = ["CASH", "BANK", "WECHAT", "ALIPAY", "CUSTOM"];

export function AccountsScreen() {
  const pop = useNavStore((s) => s.pop);
  const push = useNavStore((s) => s.push);
  const accounts = useLedgerStore((s) => s.accounts);
  const transactions = useLedgerStore((s) => s.transactions);
  const active = accounts.filter((a) => a.status === "ACTIVE");
  const total = totalBalanceFen(active, transactions);

  return (
    <div className="flex h-full flex-col">
      <TopBar
        title="账户"
        onBack={pop}
        right={
          <button
            type="button"
            aria-label="添加账户"
            className="flex size-11 items-center justify-center"
            onClick={() => push({ name: "account-edit" })}
          >
            <Plus className="size-5" />
          </button>
        }
      />
      <div className="screen-scroll px-4 pb-8">
        <div className="rounded-2xl bg-surface p-5 hairline">
          <p className="text-[12px] text-muted">全部可用余额</p>
          <p className="mt-1 text-[28px] font-bold tabular-nums">{formatFen(total)}</p>
          <p className="mt-2 text-[12px] text-muted">余额 = 开账金额 + 收入 − 支出 + 转入 − 转出</p>
        </div>
        <div className="mt-3 overflow-hidden rounded-2xl bg-surface hairline">
          {active.map((a) => {
            const Icon = ACCOUNT_ICONS[a.type];
            const bal = accountBalanceFen(a, transactions);
            return (
              <button
                key={a.id}
                type="button"
                onClick={() => push({ name: "account-edit", id: a.id })}
                className="flex min-h-16 w-full items-center gap-3 px-4 text-left"
              >
                <span className="flex size-10 items-center justify-center rounded-xl bg-primary-soft text-primary">
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[15px] font-medium">{a.name}</span>
                  <span className="text-[12px] text-muted">{ACCOUNT_TYPE_LABEL[a.type]}</span>
                </span>
                <span
                  className={cn(
                    "text-[15px] font-semibold tabular-nums",
                    bal < 0 ? "text-expense" : "text-foreground",
                  )}
                >
                  {formatFen(bal)}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function AccountEditScreen({ id }: { id?: string }) {
  const pop = useNavStore((s) => s.pop);
  const existing = useLedgerStore((s) => s.accounts.find((a) => a.id === id));
  const addAccount = useLedgerStore((s) => s.addAccount);
  const updateAccount = useLedgerStore((s) => s.updateAccount);
  const deactivateAccount = useLedgerStore((s) => s.deactivateAccount);
  const used = useLedgerStore((s) =>
    id
      ? s.transactions.some(
          (t) => t.accountId === id || t.fromAccountId === id || t.toAccountId === id,
        )
      : false,
  );
  const [name, setName] = useState(existing?.name ?? "");
  const [type, setType] = useState<AccountType>(existing?.type ?? "CASH");
  const [opening, setOpening] = useState(existing ? fenToInput(existing.openingBalanceFen) : "0");

  return (
    <div className="flex h-full flex-col">
      <TopBar title={existing ? "编辑账户" : "添加账户"} onBack={pop} />
      <div className="screen-scroll space-y-4 px-4 pb-8">
        <Field label="名称">
          <TextField value={name} onChange={setName} placeholder="例如 招商银行" />
        </Field>
        <Field label="类型">
          <div className="flex flex-wrap gap-2">
            {TYPES.map((t) => (
              <Chip key={t} active={type === t} onClick={() => setType(t)}>
                {ACCOUNT_TYPE_LABEL[t]}
              </Chip>
            ))}
          </div>
        </Field>
        <Field label="开账余额（元）">
          <TextField
            value={opening}
            onChange={(v) => {
              if (v === "" || /^-?\d*\.?\d{0,2}$/.test(v)) setOpening(v);
            }}
            placeholder="0.00"
            inputMode="decimal"
          />
        </Field>
        <PrimaryButton
          disabled={!name.trim()}
          onClick={() => {
            const openingBalanceFen = parseYuanInputToFen(opening || "0");
            if (existing) updateAccount(existing.id, { name, type, openingBalanceFen });
            else addAccount({ name, type, openingBalanceFen });
            toast.success("已保存");
            pop();
          }}
        >
          保存
        </PrimaryButton>
        {existing ? (
          <button
            type="button"
            className="flex h-11 w-full items-center justify-center gap-1.5 text-[14px] text-expense"
            onClick={async () => {
              const ok = await confirmAction({
                title: used ? "停用这个账户？" : "删除这个账户？",
                body: used
                  ? "有历史流水的账户只能停用，旧账单和余额计算仍保留。"
                  : "没有流水，将直接删除。",
                confirmLabel: used ? "停用" : "删除",
                danger: true,
              });
              if (!ok) return;
              try {
                deactivateAccount(existing.id);
                toast.success(used ? "已停用" : "已删除");
                pop();
              } catch (e) {
                toast.error(e instanceof Error ? e.message : "无法停用");
              }
            }}
          >
            <Trash2 className="size-4" /> {used ? "停用账户" : "删除账户"}
          </button>
        ) : null}
      </div>
    </div>
  );
}
