import { Database, Plane, Shield, Ban } from "lucide-react";
import { PrimaryButton, GhostButton } from "../ui";
import { useNavStore } from "@/lib/ledger/nav";
import { useLedgerStore } from "@/lib/ledger/store";

const PROMISES = [
  { icon: Database, title: "数据只留在本机", body: "不做云账号，备份由你自己导出。" },
  { icon: Plane, title: "完全离线可用", body: "飞行模式下也能记账、看统计。" },
  { icon: Shield, title: "无广告、无云同步", body: "不采集与记账无关的资料。" },
  { icon: Ban, title: "不接在线 AI", body: "判断留给你，账本只陈述事实。" },
];

export function WelcomeScreen() {
  const push = useNavStore((s) => s.push);
  const loadDemo = useLedgerStore((s) => s.loadDemo);
  const resetTo = useNavStore((s) => s.resetTo);

  return (
    <div className="flex h-full flex-col px-4 pb-[max(16px,env(safe-area-inset-bottom))] pt-[env(safe-area-inset-top)]">
      <div className="flex flex-1 flex-col">
        <div className="pt-12" />
        <LogoMark />
        <h1 className="mt-5 text-[24px] font-semibold tracking-tight">小账本</h1>
        <p className="mt-1.5 text-[14px] text-muted">记录清楚，钱才清楚。</p>
        <ul className="mt-6 space-y-2">
          {PROMISES.map((p) => {
            const Icon = p.icon;
            return (
              <li
                key={p.title}
                className="stagger-item flex gap-3 rounded-2xl bg-surface p-3.5 hairline"
              >
                <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary-soft text-primary">
                  <Icon className="size-4" strokeWidth={1.8} />
                </span>
                <span>
                  <span className="block text-[14px] font-medium">{p.title}</span>
                  <span className="mt-0.5 block text-[12px] leading-relaxed text-muted">
                    {p.body}
                  </span>
                </span>
              </li>
            );
          })}
        </ul>
      </div>
      <div className="mt-6 space-y-2">
        <PrimaryButton onClick={() => push({ name: "setup" })}>开始使用</PrimaryButton>
        <GhostButton
          onClick={() => {
            loadDemo();
            resetTo({ name: "home" });
          }}
        >
          体验示例账本
        </GhostButton>
      </div>
    </div>
  );
}

export function LogoMark({ size = 64 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="16" fill="#2C83FD" />
      <rect x="14" y="13" width="36" height="38" rx="5" fill="#EFF4FF" />
      <rect x="20" y="21" width="18" height="3.5" rx="1.75" fill="#2C83FD" />
      <rect x="20" y="29" width="24" height="3.5" rx="1.75" fill="#93C5FD" />
      <rect x="20" y="37" width="14" height="3.5" rx="1.75" fill="#93C5FD" />
      <circle cx="45" cy="44" r="9" fill="#14AE78" />
      <path
        d="M41.2 44.2l2.5 2.5 5.2-5.6"
        fill="none"
        stroke="#fff"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
