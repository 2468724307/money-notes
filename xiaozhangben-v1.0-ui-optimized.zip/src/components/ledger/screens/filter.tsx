import { Chip, Field, GhostButton, PrimaryButton, TextField, TopBar } from "../ui";
import { EMPTY_FILTER, type TransactionType } from "@/lib/ledger/types";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";

const TYPES: { id: TransactionType | "ALL"; label: string }[] = [
  { id: "ALL", label: "全部" },
  { id: "EXPENSE", label: "支出" },
  { id: "INCOME", label: "收入" },
  { id: "TRANSFER", label: "转账" },
];

export function FilterScreen() {
  const pop = useNavStore((s) => s.pop);
  const filter = useNavStore((s) => s.filter);
  const setFilter = useNavStore((s) => s.setFilter);
  const allAccounts = useLedgerStore((s) => s.accounts);
  const allCategories = useLedgerStore((s) => s.categories);
  const accounts = allAccounts.filter((a) => a.status === "ACTIVE");
  const categories = allCategories.filter((c) => c.status === "ACTIVE");

  const catOptions =
    filter.type === "INCOME"
      ? categories.filter((c) => c.type === "INCOME")
      : filter.type === "EXPENSE"
        ? categories.filter((c) => c.type === "EXPENSE")
        : categories;

  return (
    <div className="flex h-full flex-col">
      <TopBar title="筛选" onBack={pop} />
      <div className="screen-scroll space-y-4 px-5 pb-8">
        <Field label="关键词">
          <TextField
            value={filter.keyword}
            onChange={(keyword) => setFilter({ ...filter, keyword })}
            placeholder="备注 / 分类 / 账户"
          />
        </Field>
        <Field label="类型">
          <div className="flex flex-wrap gap-2">
            {TYPES.map((t) => (
              <Chip
                key={t.id}
                active={filter.type === t.id}
                onClick={() => setFilter({ ...filter, type: t.id, categoryId: "" })}
              >
                {t.label}
              </Chip>
            ))}
          </div>
        </Field>
        <Field label="日期">
          <div className="grid grid-cols-2 gap-2">
            <input
              type="date"
              value={filter.dateFrom}
              onChange={(e) => setFilter({ ...filter, dateFrom: e.target.value })}
              className="h-12 rounded-xl bg-surface-2 px-3 text-[14px]"
            />
            <input
              type="date"
              value={filter.dateTo}
              onChange={(e) => setFilter({ ...filter, dateTo: e.target.value })}
              className="h-12 rounded-xl bg-surface-2 px-3 text-[14px]"
            />
          </div>
        </Field>
        <Field label="分类">
          <div className="flex flex-wrap gap-2">
            <Chip active={!filter.categoryId} onClick={() => setFilter({ ...filter, categoryId: "" })}>
              全部
            </Chip>
            {catOptions.map((c) => (
              <Chip
                key={c.id}
                active={filter.categoryId === c.id}
                onClick={() => setFilter({ ...filter, categoryId: c.id })}
              >
                {c.name}
              </Chip>
            ))}
          </div>
        </Field>
        <Field label="账户">
          <div className="flex flex-wrap gap-2">
            <Chip active={!filter.accountId} onClick={() => setFilter({ ...filter, accountId: "" })}>
              全部
            </Chip>
            {accounts.map((a) => (
              <Chip
                key={a.id}
                active={filter.accountId === a.id}
                onClick={() => setFilter({ ...filter, accountId: a.id })}
              >
                {a.name}
              </Chip>
            ))}
          </div>
        </Field>
        <Field label="金额区间（元）">
          <div className="grid grid-cols-2 gap-2">
            <TextField
              value={filter.amountMinYuan}
              onChange={(amountMinYuan) => setFilter({ ...filter, amountMinYuan })}
              placeholder="最小"
              inputMode="decimal"
            />
            <TextField
              value={filter.amountMaxYuan}
              onChange={(amountMaxYuan) => setFilter({ ...filter, amountMaxYuan })}
              placeholder="最大"
              inputMode="decimal"
            />
          </div>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-2 px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
        <GhostButton onClick={() => setFilter({ ...EMPTY_FILTER })}>重置</GhostButton>
        <PrimaryButton onClick={pop}>确定</PrimaryButton>
      </div>
    </div>
  );
}
