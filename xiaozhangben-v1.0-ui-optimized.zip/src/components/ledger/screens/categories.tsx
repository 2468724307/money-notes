import { useState } from "react";
import { ChevronDown, ChevronUp, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Chip,
  Field,
  PrimaryButton,
  SegmentedControl,
  TextField,
  ToolbarButton,
  TopBar,
} from "../ui";
import { confirmAction } from "@/lib/ledger/confirm";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { CATEGORY_ICON_KEYS } from "@/lib/ledger/defaults";
import { categoryIcon } from "@/lib/ledger/icons";
import type { CategoryType } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

export function CategoriesScreen({
  kind: initialKind,
  pick,
}: {
  kind: CategoryType;
  pick?: boolean;
}) {
  const [kind, setKind] = useState<CategoryType>(initialKind);
  const pop = useNavStore((s) => s.pop);
  const categories = useLedgerStore((s) => s.categories);
  const addCategory = useLedgerStore((s) => s.addCategory);
  const updateCategory = useLedgerStore((s) => s.updateCategory);
  const deactivateCategory = useLedgerStore((s) => s.deactivateCategory);
  const moveCategory = useLedgerStore((s) => s.moveCategory);
  const txs = useLedgerStore((s) => s.transactions);
  const patchSettings = useLedgerStore((s) => s.patchSettings);

  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("more");
  const [editingId, setEditingId] = useState<string | null>(null);

  const list = categories
    .filter((c) => c.type === kind && c.status === "ACTIVE")
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className="flex h-full flex-col">
      <TopBar
        title={kind === "INCOME" ? "收入分类" : "支出分类"}
        onBack={pop}
        right={
          <ToolbarButton
            label="新增分类"
            onClick={() => {
              setAdding(true);
              setEditingId(null);
              setName("");
              setIcon("more");
            }}
          >
            <Plus className="size-5" />
          </ToolbarButton>
        }
      />
      <p className="px-4 pb-2 text-[12px] text-muted">
        有历史账单的分类只能停用，不能删掉，旧记录仍会显示原来的名字。
      </p>
      {!pick ? (
        <div className="px-4 pb-3">
          <SegmentedControl
            label="分类类型"
            value={kind}
            options={[
              { value: "EXPENSE", label: "支出" },
              { value: "INCOME", label: "收入" },
            ]}
            onChange={setKind}
          />
        </div>
      ) : null}
      <div className="screen-scroll px-4 pb-8">
        <div className="grid grid-cols-4 gap-2">
          {list.map((c) => {
            const Icon = categoryIcon(c.icon);
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  if (pick) {
                    if (kind === "EXPENSE") patchSettings({ lastUsedExpenseCategoryId: c.id });
                    else patchSettings({ lastUsedIncomeCategoryId: c.id });
                    pop();
                    return;
                  }
                  setEditingId(c.id);
                  setAdding(false);
                  setName(c.name);
                  setIcon(c.icon);
                }}
                className="flex h-16 flex-col items-center justify-center gap-1 rounded-xl bg-surface hairline"
              >
                <Icon className="size-5 text-primary" strokeWidth={1.7} />
                <span className="text-[12px]">{c.name}</span>
              </button>
            );
          })}
        </div>

        {(adding || editingId) && (
          <div className="mt-5 rounded-2xl bg-surface p-4 hairline">
            <h2 className="text-[14px] font-semibold">{editingId ? "编辑分类" : "新增分类"}</h2>
            <div className="mt-3 space-y-3">
              <Field label="名称">
                <TextField value={name} onChange={setName} placeholder="分类名" />
              </Field>
              <Field label="图标">
                <div className="flex flex-wrap gap-2">
                  {CATEGORY_ICON_KEYS.map((key) => {
                    const Icon = categoryIcon(key);
                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => setIcon(key)}
                        className={cn(
                          "flex size-10 items-center justify-center rounded-xl",
                          icon === key ? "bg-primary text-primary-foreground" : "bg-surface-2",
                        )}
                      >
                        <Icon className="size-4" />
                      </button>
                    );
                  })}
                </div>
              </Field>
              {editingId ? (
                <div className="flex gap-2">
                  <Chip onClick={() => moveCategory(editingId, -1)}>
                    <span className="inline-flex items-center gap-1">
                      <ChevronUp className="size-3.5" /> 前移
                    </span>
                  </Chip>
                  <Chip onClick={() => moveCategory(editingId, 1)}>
                    <span className="inline-flex items-center gap-1">
                      <ChevronDown className="size-3.5" /> 后移
                    </span>
                  </Chip>
                </div>
              ) : null}
              <PrimaryButton
                disabled={!name.trim()}
                onClick={() => {
                  if (editingId) updateCategory(editingId, { name, icon });
                  else addCategory({ name, type: kind, icon });
                  toast.success("已保存");
                  setAdding(false);
                  setEditingId(null);
                }}
              >
                保存
              </PrimaryButton>
              {editingId ? (
                <button
                  type="button"
                  className="flex h-11 w-full items-center justify-center gap-1.5 rounded-xl text-[14px] text-expense"
                  onClick={async () => {
                    const used = txs.some((t) => t.categoryId === editingId);
                    const ok = await confirmAction({
                      title: used ? "停用这个分类？" : "删除这个分类？",
                      body: used
                        ? "历史账单仍会显示它，只是新账单里不能再选。"
                        : "没有历史账单，将直接删除。",
                      confirmLabel: used ? "停用" : "删除",
                      danger: true,
                    });
                    if (!ok) return;
                    deactivateCategory(editingId);
                    toast.success(used ? "已停用" : "已删除");
                    setEditingId(null);
                  }}
                >
                  <Trash2 className="size-4" />
                  {txs.some((t) => t.categoryId === editingId) ? "停用" : "删除"}
                </button>
              ) : null}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
