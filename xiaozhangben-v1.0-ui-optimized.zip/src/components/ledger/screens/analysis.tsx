import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { TopBar } from "../ui";
import { MonthSwitcher } from "../chrome";
import { TxRow } from "../tx-row";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen, fenToYuanString } from "@/lib/ledger/money";
import { formatMonthTitle, shiftMonth } from "@/lib/ledger/dates";
import { categoryRank, inMonth, monthCompare } from "@/lib/ledger/formulas";
import { categoryIcon } from "@/lib/ledger/icons";

export function AnalysisScreen({ categoryId }: { categoryId: string }) {
  const pop = useNavStore((s) => s.pop);
  const push = useNavStore((s) => s.push);
  const month = useNavStore((s) => s.month);
  const setMonth = useNavStore((s) => s.setMonth);
  const categories = useLedgerStore((s) => s.categories);
  const accounts = useLedgerStore((s) => s.accounts);
  const transactions = useLedgerStore((s) => s.transactions);
  const cat = categories.find((c) => c.id === categoryId);
  const type = cat?.type === "INCOME" ? "INCOME" : "EXPENSE";
  const rank = categoryRank(transactions, month, type, categories);
  const row = rank.rows.find((r) => r.categoryId === categoryId);
  const amount = row?.amountFen ?? 0;
  const percent = row?.percent ?? 0;
  const bills = transactions.filter((t) => t.categoryId === categoryId && inMonth(t, month));
  const compare = monthCompare(transactions, month, 5).map((m) => {
    const fen = transactions
      .filter((t) => t.categoryId === categoryId && inMonth(t, m.month))
      .reduce((s, t) => s + t.amountFen, 0);
    return {
      name: `${Number(m.month.slice(5))}月`,
      value: Number(fenToYuanString(fen)),
      label: formatFen(fen),
    };
  });
  const Icon = categoryIcon(cat?.icon ?? "more");

  return (
    <div className="flex h-full flex-col">
      <TopBar title={cat?.name ?? "分类"} onBack={pop} />
      <div className="px-4">
        <MonthSwitcher
          month={month}
          label={formatMonthTitle(month)}
          onPrev={() => setMonth(shiftMonth(month, -1))}
          onNext={() => setMonth(shiftMonth(month, 1))}
        />
      </div>
      <div className="screen-scroll px-4 pb-6">
        <div className="mt-3 rounded-2xl bg-surface p-4 hairline">
          <div className="flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-xl bg-primary-soft text-primary">
              <Icon className="size-5" />
            </span>
            <div>
              <p className="text-[13px] text-muted">
                {type === "INCOME" ? "本月收入" : "本月支出"}
              </p>
              <p className="text-[22px] font-bold tabular-nums">{formatFen(amount)}</p>
            </div>
          </div>
          <p className="mt-3 text-[13px] text-muted">
            占本月{type === "INCOME" ? "收入" : "支出"} {(percent * 100).toFixed(1)}% · 共{" "}
            {bills.length} 笔
          </p>
        </div>
        <h2 className="mt-5 text-[15px] font-semibold">近半年趋势</h2>
        <div className="mt-2 h-40 rounded-2xl bg-surface p-2 hairline">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={compare}>
              <XAxis
                dataKey="name"
                tick={{ fontSize: 11, fill: "var(--color-muted)" }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                content={({ payload, label }) => {
                  const row = payload?.[0]?.payload as (typeof compare)[number] | undefined;
                  if (!row) return null;
                  return (
                    <div className="rounded-lg bg-surface px-3 py-2 text-[12px] shadow-[var(--shadow-card)]">
                      {label} {row.label}
                    </div>
                  );
                }}
              />
              <Bar dataKey="value" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <h2 className="mt-5 text-[15px] font-semibold">对应账单</h2>
        <div className="system-list mt-2 overflow-hidden">
          {bills.length === 0 ? (
            <p className="px-4 py-8 text-center text-[13px] text-muted">本月该分类没有账单</p>
          ) : (
            bills.map((tx) => (
              <TxRow
                key={tx.id}
                tx={tx}
                accounts={accounts}
                categories={categories}
                onClick={() => push({ name: "detail", id: tx.id })}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
