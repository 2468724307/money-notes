import {
  ArrowLeftRight,
  ChevronRight,
  Minus,
  PiggyBank,
  Plus,
  Receipt,
  TrendingDown,
  WalletCards,
} from "lucide-react";
import { Card, EmptyState, PrimaryButton } from "../ui";
import { MonthSwitcher, ProgressBar, RecordMenuButton } from "../chrome";
import { TxRow } from "../tx-row";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen } from "@/lib/ledger/money";
import { formatMonthTitle, monthKey, shiftMonth, startOfDay } from "@/lib/ledger/dates";
import {
  budgetStatus,
  budgetUsedFen,
  categoryRank,
  findBudget,
  inMonth,
  monthTotals,
  totalBalanceFen,
} from "@/lib/ledger/formulas";
import { cn } from "@/lib/utils";

export function HomeScreen() {
  const settings = useLedgerStore((s) => s.settings);
  const accounts = useLedgerStore((s) => s.accounts);
  const categories = useLedgerStore((s) => s.categories);
  const transactions = useLedgerStore((s) => s.transactions);
  const budgets = useLedgerStore((s) => s.budgets);
  const month = useNavStore((s) => s.month);
  const setMonth = useNavStore((s) => s.setMonth);
  const push = useNavStore((s) => s.push);

  const totals = monthTotals(transactions, month);
  const previous = monthTotals(transactions, shiftMonth(month, -1));
  const balance = totalBalanceFen(accounts, transactions);
  const recent = transactions.filter((t) => inMonth(t, month)).slice(0, 5);
  const totalBudget = findBudget(budgets, month, null);
  const used = budgetUsedFen(transactions, month, null);
  const tone = totalBudget ? budgetStatus(used, totalBudget.amountFen) : "ok";
  const topCategory = categoryRank(transactions, month, "EXPENSE", categories).rows[0];
  const todayStart = startOfDay(Date.now());
  const todayExpense = transactions.reduce(
    (sum, tx) => sum + (tx.type === "EXPENSE" && tx.occurredAt >= todayStart ? tx.amountFen : 0),
    0,
  );
  const expenseDelta =
    previous.expense > 0
      ? Math.round(((totals.expense - previous.expense) / previous.expense) * 100)
      : null;
  const now = new Date();
  const isCurrentMonth = month === monthKey();
  const daysLeft = Math.max(
    1,
    new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate() - now.getDate() + 1,
  );
  const dailyAvailable = totalBudget
    ? Math.max(0, totalBudget.amountFen - used) / (isCurrentMonth ? daysLeft : 1)
    : null;

  const openRecord = (type: "EXPENSE" | "INCOME" | "TRANSFER") => push({ name: "record", type });

  return (
    <div className="flex h-full flex-col">
      <header className="shrink-0 px-4 pb-2 pt-[calc(12px+env(safe-area-inset-top))]">
        <div className="flex items-end justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[12px] text-muted">离线私人账本</p>
            <h1 className="mt-0.5 truncate text-[24px] font-semibold leading-8 tracking-tight">
              {settings.bookName}
            </h1>
          </div>
          <div className="flex items-center gap-1">
            <MonthSwitcher
              month={month}
              label={formatMonthTitle(month)}
              onPrev={() => setMonth(shiftMonth(month, -1))}
              onNext={() => setMonth(shiftMonth(month, 1))}
              compact
            />
            <RecordMenuButton />
          </div>
        </div>
      </header>

      <div className="screen-scroll px-4 pb-6">
        <Card className="hero-card mt-2 overflow-hidden p-4">
          <button
            type="button"
            onClick={() => push({ name: "accounts" })}
            className="pressable w-full text-left"
          >
            <div className="flex items-center justify-between">
              <p className="text-[12px] font-medium text-muted">全部账户余额</p>
              <span className="flex items-center text-[11px] text-primary">
                账户 <ChevronRight className="size-3.5" />
              </span>
            </div>
            <p className="amount-display mt-1 text-[30px] font-semibold leading-9 tabular-nums text-foreground">
              {formatFen(balance)}
            </p>
          </button>
          <div className="mt-4 grid grid-cols-3 divide-x divide-divider rounded-xl bg-surface-2 px-1 py-3">
            <HeroMetric label="收入" value={formatFen(totals.income)} />
            <HeroMetric label="支出" value={formatFen(totals.expense)} />
            <HeroMetric label="结余" value={formatFen(totals.surplus, { sign: true })} />
          </div>
        </Card>

        <section className="mt-3 grid grid-cols-4 gap-2" aria-label="快捷操作">
          <QuickAction
            label="支出"
            icon={Minus}
            tone="expense"
            onClick={() => openRecord("EXPENSE")}
          />
          <QuickAction
            label="收入"
            icon={Plus}
            tone="income"
            onClick={() => openRecord("INCOME")}
          />
          <QuickAction
            label="转账"
            icon={ArrowLeftRight}
            tone="primary"
            onClick={() => openRecord("TRANSFER")}
          />
          <QuickAction
            label="预算"
            icon={PiggyBank}
            tone="warning"
            onClick={() => push({ name: "budget" })}
          />
        </section>

        <div className="mt-5 flex items-center justify-between px-1">
          <h2 className="text-[16px] font-semibold">本月概览</h2>
          <span className="text-[11px] text-muted">根据本机账单计算</span>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <InsightCard
            icon={TrendingDown}
            label={isCurrentMonth ? "今日支出" : "月均支出"}
            value={formatFen(isCurrentMonth ? todayExpense : totals.expense)}
            hint={
              expenseDelta == null
                ? "暂无上月对比"
                : `较上月${expenseDelta >= 0 ? "增加" : "减少"} ${Math.abs(expenseDelta)}%`
            }
            tone={expenseDelta != null && expenseDelta > 0 ? "expense" : "primary"}
          />
          <InsightCard
            icon={WalletCards}
            label="支出最多"
            value={topCategory?.category?.name ?? "暂无"}
            hint={topCategory ? formatFen(topCategory.amountFen) : "记录后自动分析"}
            tone="income"
          />
        </div>

        {totalBudget ? (
          <button
            type="button"
            onClick={() => push({ name: "budget" })}
            className="pressable soft-card mt-2 w-full rounded-2xl bg-surface p-4 text-left"
          >
            <div className="mb-2 flex items-center justify-between gap-2 text-[13px]">
              <span className="font-medium">预算进度</span>
              <span className="truncate tabular-nums text-muted">
                {Math.round((used / totalBudget.amountFen) * 100)}%
              </span>
            </div>
            <ProgressBar
              ratio={totalBudget.amountFen ? used / totalBudget.amountFen : 0}
              tone={tone}
            />
            <div className="mt-2 flex items-center justify-between gap-3 text-[11px] text-muted">
              <span>
                已用 {formatFen(used)} / {formatFen(totalBudget.amountFen)}
              </span>
              <span
                className={cn(tone === "over" && "text-expense", tone === "warn" && "text-warning")}
              >
                {tone === "over"
                  ? `超出 ${formatFen(used - totalBudget.amountFen)}`
                  : dailyAvailable != null && isCurrentMonth
                    ? `日均可用 ${formatFen(dailyAvailable)}`
                    : `剩余 ${formatFen(totalBudget.amountFen - used)}`}
              </span>
            </div>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => push({ name: "budget" })}
            className="pressable mt-2 flex w-full items-center gap-3 rounded-2xl bg-warning-soft p-3 text-left text-warning"
          >
            <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-white/75">
              <PiggyBank className="size-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[13px] font-semibold">设置月度预算</span>
              <span className="block text-[11px] opacity-80">开启预算进度和每日可用提醒</span>
            </span>
            <ChevronRight className="size-4" />
          </button>
        )}

        <div className="mt-5 flex items-center justify-between px-1">
          <h2 className="text-[16px] font-semibold">最近账单</h2>
          <button
            type="button"
            className="pressable flex h-8 items-center text-[12px] text-primary"
            onClick={() => useNavStore.getState().goTab("bills")}
          >
            全部 <ChevronRight className="size-3.5" />
          </button>
        </div>

        {recent.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="还没有账单"
            body="记下第一笔收支，概览与统计会自动更新。"
            action={
              <PrimaryButton tone="expense" onClick={() => openRecord("EXPENSE")}>
                记第一笔
              </PrimaryButton>
            }
          />
        ) : (
          <div className="soft-card mt-2 overflow-hidden rounded-2xl bg-surface">
            {recent.map((tx, index) => (
              <div key={tx.id} className={cn(index > 0 && "border-t border-divider/70")}>
                <TxRow
                  tx={tx}
                  accounts={accounts}
                  categories={categories}
                  onClick={() => push({ name: "detail", id: tx.id })}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function HeroMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 px-2">
      <p className="text-[10px] text-muted">{label}</p>
      <p className="mt-1 truncate text-[13px] font-semibold tabular-nums text-foreground">
        {value}
      </p>
    </div>
  );
}

function QuickAction({
  label,
  icon: Icon,
  tone,
  onClick,
}: {
  label: string;
  icon: typeof Plus;
  tone: "expense" | "income" | "primary" | "warning";
  onClick: () => void;
}) {
  const tones = {
    expense: "bg-expense-soft text-expense",
    income: "bg-income-soft text-income",
    primary: "bg-primary-soft text-primary",
    warning: "bg-warning-soft text-warning",
  };
  return (
    <button
      type="button"
      onClick={onClick}
      className="pressable soft-card flex min-h-[72px] flex-col items-center justify-center rounded-xl bg-surface text-[12px] font-medium"
    >
      <span
        className={cn("mb-1.5 flex size-8 items-center justify-center rounded-lg", tones[tone])}
      >
        <Icon className="size-4" strokeWidth={2} />
      </span>
      {label}
    </button>
  );
}

function InsightCard({
  icon: Icon,
  label,
  value,
  hint,
  tone,
}: {
  icon: typeof TrendingDown;
  label: string;
  value: string;
  hint: string;
  tone: "expense" | "income" | "primary";
}) {
  const tones = {
    expense: "bg-expense-soft text-expense",
    income: "bg-income-soft text-income",
    primary: "bg-primary-soft text-primary",
  };
  return (
    <div className="soft-card rounded-2xl bg-surface p-3">
      <div className="flex items-center gap-2">
        <span className={cn("flex size-8 items-center justify-center rounded-lg", tones[tone])}>
          <Icon className="size-4" />
        </span>
        <span className="text-[11px] text-muted">{label}</span>
      </div>
      <p className="mt-2 truncate text-[18px] font-semibold tabular-nums">{value}</p>
      <p className="mt-0.5 truncate text-[10px] text-muted">{hint}</p>
    </div>
  );
}
