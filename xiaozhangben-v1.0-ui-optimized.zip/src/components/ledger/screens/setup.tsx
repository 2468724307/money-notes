import { useState } from "react";
import { Chip, Field, PrimaryButton, TextField, TopBar } from "../ui";
import { useNavStore } from "@/lib/ledger/nav";
import { useLedgerStore } from "@/lib/ledger/store";
import { ACCOUNT_TYPE_LABEL } from "@/lib/ledger/defaults";
import type { AccountType } from "@/lib/ledger/types";
import { parseYuanInputToFen } from "@/lib/ledger/money";

const TYPES: AccountType[] = ["CASH", "BANK", "WECHAT", "ALIPAY", "CUSTOM"];

export function SetupScreen() {
  const pop = useNavStore((s) => s.pop);
  const resetTo = useNavStore((s) => s.resetTo);
  const completeSetup = useLedgerStore((s) => s.completeSetup);
  const [bookName, setBookName] = useState("小账本");
  const [accountName, setAccountName] = useState("现金");
  const [accountType, setAccountType] = useState<AccountType>("CASH");
  const [balance, setBalance] = useState("0");

  const canFinish = bookName.trim().length > 0 && accountName.trim().length > 0;

  return (
    <div className="flex h-full flex-col">
      <TopBar title="初始设置" onBack={pop} />
      <div className="screen-scroll px-4 pb-6">
        <p className="mb-5 text-[13px] leading-relaxed text-muted">
          先建一个常用账户。余额从开账金额和之后的流水计算，随时可再加账户。
        </p>
        <div className="space-y-4">
          <Field label="账本名称">
            <TextField value={bookName} onChange={setBookName} placeholder="小账本" />
          </Field>
          <Field label="账户名称">
            <TextField value={accountName} onChange={setAccountName} placeholder="现金" />
          </Field>
          <Field label="账户类型">
            <div className="flex flex-wrap gap-2">
              {TYPES.map((t) => (
                <Chip key={t} active={accountType === t} onClick={() => setAccountType(t)}>
                  {ACCOUNT_TYPE_LABEL[t]}
                </Chip>
              ))}
            </div>
          </Field>
          <Field label="初始余额（元）">
            <TextField
              value={balance}
              onChange={(v) => {
                if (v === "" || /^-?\d*\.?\d{0,2}$/.test(v)) setBalance(v);
              }}
              placeholder="0.00"
              inputMode="decimal"
            />
          </Field>
        </div>
      </div>
      <div className="px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-2">
        <PrimaryButton
          disabled={!canFinish}
          onClick={() => {
            completeSetup({
              bookName,
              accountName,
              accountType,
              openingBalanceFen: parseYuanInputToFen(balance || "0"),
            });
            resetTo({ name: "home" });
          }}
        >
          完成，进入账本
        </PrimaryButton>
      </div>
    </div>
  );
}
