import { toast } from "sonner";
import { Pencil, Trash2 } from "lucide-react";
import { GhostButton, PrimaryButton, TopBar } from "../ui";
import { confirmAction } from "@/lib/ledger/confirm";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen } from "@/lib/ledger/money";
import { formatDateTime } from "@/lib/ledger/dates";
import { ACCOUNT_TYPE_LABEL } from "@/lib/ledger/defaults";
import { cn } from "@/lib/utils";

export function DetailScreen({ id }: { id: string }) {
  const tx = useLedgerStore((s) => s.transactions.find((t) => t.id === id));
  const accounts = useLedgerStore((s) => s.accounts);
  const categories = useLedgerStore((s) => s.categories);
  const pop = useNavStore((s) => s.pop);
  const push = useNavStore((s) => s.push);
  const deleteTransaction = useLedgerStore((s) => s.deleteTransaction);

  if (!tx) {
    return (
      <div className="flex h-full flex-col">
        <TopBar title="账单详情" onBack={pop} />
        <p className="px-4 py-10 text-sm text-muted">这笔账单已经不在了。</p>
      </div>
    );
  }

  const cat = categories.find((c) => c.id === tx.categoryId);
  const acc = accounts.find((a) => a.id === tx.accountId);
  const from = accounts.find((a) => a.id === tx.fromAccountId);
  const to = accounts.find((a) => a.id === tx.toAccountId);
  const tone =
    tx.type === "INCOME" ? "text-income" : tx.type === "EXPENSE" ? "text-expense" : "text-primary";
  const typeLabel = tx.type === "INCOME" ? "收入" : tx.type === "EXPENSE" ? "支出" : "转账";

  return (
    <div className="flex h-full flex-col">
      <TopBar title="账单详情" onBack={pop} />
      <div className="screen-scroll px-4 pb-8">
        <div className="py-6 text-center">
          <p className="text-[13px] text-muted">{typeLabel}</p>
          <p className={cn("mt-2 text-[32px] font-bold tabular-nums leading-none", tone)}>
            {tx.type === "EXPENSE"
              ? formatFen(-tx.amountFen, { sign: true })
              : tx.type === "INCOME"
                ? formatFen(tx.amountFen, { sign: true })
                : formatFen(tx.amountFen)}
          </p>
        </div>
        <div className="system-list overflow-hidden">
          <Info
            label="分类"
            value={tx.type === "TRANSFER" ? "转账（不计入收支）" : (cat?.name ?? "未分类")}
          />
          {tx.type === "TRANSFER" ? (
            <>
              <Info
                label="转出账户"
                value={from ? `${from.name} · ${ACCOUNT_TYPE_LABEL[from.type]}` : "—"}
              />
              <Info
                label="转入账户"
                value={to ? `${to.name} · ${ACCOUNT_TYPE_LABEL[to.type]}` : "—"}
              />
            </>
          ) : (
            <Info
              label="账户"
              value={acc ? `${acc.name} · ${ACCOUNT_TYPE_LABEL[acc.type]}` : "—"}
            />
          )}
          <Info label="时间" value={formatDateTime(tx.occurredAt)} />
          <Info label="备注" value={tx.note || "无"} last />
        </div>
        <div className="mt-6 grid grid-cols-2 gap-2">
          <GhostButton onClick={() => push({ name: "record", type: tx.type, editId: tx.id })}>
            <span className="inline-flex items-center gap-1.5">
              <Pencil className="size-4" /> 编辑
            </span>
          </GhostButton>
          <PrimaryButton
            tone="expense"
            onClick={async () => {
              const ok = await confirmAction({
                title: "删除这笔账单？",
                body: "删除后无法恢复。首页、账单、统计、预算和账户余额会一起更新。",
                confirmLabel: "删除",
                danger: true,
              });
              if (!ok) return;
              deleteTransaction(tx.id);
              toast.success("已删除");
              pop();
            }}
          >
            <span className="inline-flex items-center gap-1.5">
              <Trash2 className="size-4" /> 删除
            </span>
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
}

function Info({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <div
      className={cn(
        "flex items-start justify-between gap-4 px-4 py-3.5",
        !last && "border-b border-divider",
      )}
    >
      <span className="shrink-0 text-[13px] text-muted">{label}</span>
      <span className="text-right text-[14px]">{value}</span>
    </div>
  );
}
