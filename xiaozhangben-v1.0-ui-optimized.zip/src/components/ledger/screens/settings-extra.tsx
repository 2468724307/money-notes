import { Chip, TopBar } from "../ui";
import { LogoMark } from "./welcome";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import type { ThemeMode } from "@/lib/ledger/types";
import { applyTheme } from "../theme";

export function AppearanceScreen() {
  const pop = useNavStore((s) => s.pop);
  const theme = useLedgerStore((s) => s.settings.theme);
  const bookName = useLedgerStore((s) => s.settings.bookName);
  const patchSettings = useLedgerStore((s) => s.patchSettings);

  function setTheme(next: ThemeMode) {
    patchSettings({ theme: next });
    applyTheme(next);
  }

  return (
    <div className="flex h-full flex-col">
      <TopBar title="外观" onBack={pop} />
      <div className="px-5">
        <p className="mb-3 text-[12px] text-muted">只影响本机显示，不上传任何设置。</p>
        <p className="mb-2 text-[13px] font-medium">主题</p>
        <div className="flex flex-wrap gap-2">
          <Chip active={theme === "light"} onClick={() => setTheme("light")}>
            浅色
          </Chip>
          <Chip active={theme === "dark"} onClick={() => setTheme("dark")}>
            深色
          </Chip>
          <Chip active={theme === "system"} onClick={() => setTheme("system")}>
            跟随系统
          </Chip>
        </div>
        <p className="mt-6 mb-2 text-[13px] font-medium">账本名称</p>
        <input
          value={bookName}
          onChange={(e) => patchSettings({ bookName: e.target.value.slice(0, 20) })}
          className="h-12 w-full rounded-xl bg-surface-2 px-3.5 text-[15px] outline-none"
        />
      </div>
    </div>
  );
}

export function AboutScreen() {
  const pop = useNavStore((s) => s.pop);
  return (
    <div className="flex h-full flex-col">
      <TopBar title="关于" onBack={pop} />
      <div className="screen-scroll px-5 pb-8 text-center">
        <div className="flex justify-center pt-6">
          <LogoMark />
        </div>
        <h2 className="mt-4 text-[20px] font-bold">小账本</h2>
        <p className="mt-1 text-[13px] text-muted">V1.0 · 离线单人版</p>
        <ul className="mt-8 space-y-3 text-left text-[14px] leading-relaxed text-muted">
          <li className="rounded-2xl bg-surface p-4 hairline">交易是唯一事实来源。首页、统计、预算、账户余额都从流水计算。</li>
          <li className="rounded-2xl bg-surface p-4 hairline">金额以「分」保存，不做浮点运算。</li>
          <li className="rounded-2xl bg-surface p-4 hairline">转账不计入收入和支出；分类/账户停用不破坏历史。</li>
          <li className="rounded-2xl bg-surface p-4 hairline">无联网 AI、无云同步、无广告。核心功能在飞行模式下全部可用。</li>
        </ul>
      </div>
    </div>
  );
}
