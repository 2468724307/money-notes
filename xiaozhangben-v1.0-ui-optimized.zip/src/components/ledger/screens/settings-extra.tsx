import { SectionLabel, SegmentedControl, TopBar } from "../ui";
import { LogoMark } from "./welcome";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import type { ThemeMode } from "@/lib/ledger/types";
import { applyTheme } from "../theme";

export function AppearanceScreen() {
  const pop = useNavStore((s) => s.pop);
  const theme = useLedgerStore((s) => s.settings.theme);
  const bookName = useLedgerStore((s) => s.settings.bookName);
  const patchSettings = useLedgerStore((s) => s.patchSettings);

  function setTheme(next: ThemeMode) {
    patchSettings({ theme: next });
    applyTheme(next);
  }

  return (
    <div className="flex h-full flex-col">
      <TopBar title="外观" onBack={pop} />
      <div className="screen-scroll pb-8">
        <SectionLabel>显示</SectionLabel>
        <div className="system-list mx-4 overflow-hidden">
          <div className="p-4">
            <p className="mb-2 text-[13px] text-muted">主题</p>
            <SegmentedControl
              label="显示主题"
              value={theme}
              options={[
                { value: "light", label: "浅色" },
                { value: "dark", label: "深色" },
                { value: "system", label: "自动" },
              ]}
              onChange={setTheme}
            />
          </div>
          <label className="block border-t border-divider px-4 py-3">
            <span className="mb-1.5 block text-[13px] text-muted">账本名称</span>
            <input
              value={bookName}
              onChange={(e) => patchSettings({ bookName: e.target.value.slice(0, 20) })}
              className="h-10 w-full bg-transparent text-[16px] outline-none placeholder:text-subtle"
            />
          </label>
        </div>
        <p className="px-4 pt-2 text-[12px] leading-relaxed text-muted">
          外观设置只保存在本机；“自动”会跟随系统深浅色切换。
        </p>
      </div>
    </div>
  );
}

export function AboutScreen() {
  const pop = useNavStore((s) => s.pop);
  return (
    <div className="flex h-full flex-col">
      <TopBar title="关于" onBack={pop} />
      <div className="screen-scroll px-4 pb-8 text-center">
        <div className="flex justify-center pt-6">
          <LogoMark />
        </div>
        <h2 className="mt-4 text-[20px] font-bold">小账本</h2>
        <p className="mt-1 text-[13px] text-muted">V2.1 · HIG 重构版</p>
        <ul className="system-list mt-8 overflow-hidden text-left text-[14px] leading-relaxed text-muted">
          <li className="px-4 py-3.5">
            交易是唯一事实来源。首页、统计、预算、账户余额都从流水计算。
          </li>
          <li className="border-t border-divider px-4 py-3.5">金额以「分」保存，不做浮点运算。</li>
          <li className="border-t border-divider px-4 py-3.5">
            转账不计入收入和支出；分类/账户停用不破坏历史。
          </li>
          <li className="border-t border-divider px-4 py-3.5">
            无联网 AI、无云同步、无广告。核心功能在飞行模式下全部可用。
          </li>
        </ul>
      </div>
    </div>
  );
}
