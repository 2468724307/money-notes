import { Search, SlidersHorizontal, Receipt, XCircle } from "lucide-react";
import { EmptyState, SegmentedControl, ToolbarButton, TopBar } from "../ui";
import { MonthSwitcher, RecordMenuButton } from "../chrome";
import { TxRow } from "../tx-row";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen } from "@/lib/ledger/money";
import { formatDayHeading, formatMonthTitle, shiftMonth, startOfDay } from "@/lib/ledger/dates";
import { filterTransactions, inMonth, isFilterActive, monthTotals } from "@/lib/ledger/formulas";
import type { Transaction } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

export function BillsScreen() {
  const transactions = useLedgerStore((s) => s.transactions);
  const accounts = useLedgerStore((s) => s.accounts);
  const categories = useLedgerStore((s) => s.categories);
  const month = useNavStore((s) => s.month);
  const setMonth = useNavStore((s) => s.setMonth);
  const filter = useNavStore((s) => s.filter);
  const setFilter = useNavStore((s) => s.setFilter);
  const clearFilter = useNavStore((s) => s.clearFilter);
  const push = useNavStore((s) => s.push);
  const filteredOn = isFilterActive(filter);

  const monthTx = transactions.filter((t) => inMonth(t, month));
  const list = filteredOn ? filterTransactions(monthTx, filter, accounts, categories) : monthTx;
  const totals = monthTotals(list, month);
  const groups = groupByDay(list);

  return (
    <div className="flex h-full flex-col">
      <TopBar
        title="账单"
        right={
          <div className="flex">
            <RecordMenuButton />
            <ToolbarButton
              label="筛选"
              active={filteredOn}
              onClick={() => push({ name: "filter" })}
            >
              <SlidersHorizontal className="size-5" strokeWidth={1.8} />
            </ToolbarButton>
          </div>
        }
      />
      <div className="px-4 pb-2">
        <MonthSwitcher
          month={month}
          label={formatMonthTitle(month)}
          onPrev={() => setMonth(shiftMonth(month, -1))}
          onNext={() => setMonth(shiftMonth(month, 1))}
        />
        <div className="system-search relative mt-3" role="search">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
          <input
            value={filter.keyword}
            onChange={(e) => setFilter({ ...filter, keyword: e.target.value })}
            placeholder="搜索备注、分类、账户"
            aria-label="搜索账单"
            className="h-10 w-full rounded-xl bg-surface-2 pl-10 pr-10 text-[14px] outline-none focus:ring-2 focus:ring-primary/25"
          />
          {filter.keyword ? (
            <button
              type="button"
              aria-label="清除搜索"
              onClick={() => setFilter({ ...filter, keyword: "" })}
              className="absolute right-0 top-1/2 flex size-10 -translate-y-1/2 items-center justify-center text-subtle"
            >
              <XCircle className="size-4" fill="currentColor" strokeWidth={0} />
            </button>
          ) : null}
        </div>
        <div className="mt-2">
          <SegmentedControl
            label="账单类型"
            value={filter.type}
            options={[
              { value: "ALL", label: "全部" },
              { value: "EXPENSE", label: "支出" },
              { value: "INCOME", label: "收入" },
              { value: "TRANSFER", label: "转账" },
            ]}
            onChange={(type) => setFilter({ ...filter, type })}
          />
        </div>
        <div className="system-list mt-3 grid grid-cols-3 divide-x divide-divider text-center">
          <SummaryCell label="收入" value={formatFen(totals.income)} tone="text-income" />
          <SummaryCell label="支出" value={formatFen(totals.expense)} tone="text-expense" />
          <SummaryCell label="结余" value={formatFen(totals.surplus, { sign: true })} />
        </div>
        {filteredOn ? (
          <button
            type="button"
            onClick={clearFilter}
            className="pressable mt-2 text-[12px] text-primary"
          >
            共 {list.length} 笔 · 清除全部筛选
          </button>
        ) : null}
      </div>
      <div className="screen-scroll pb-4">
        {list.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title={filteredOn ? "没有匹配的账单" : "这个月还没有账单"}
            body={filteredOn ? "试试放宽条件，或清除筛选。" : "点击右上角加号即可记一笔。"}
            action={
              filteredOn ? (
                <button
                  type="button"
                  onClick={clearFilter}
                  className="h-11 rounded-xl bg-primary px-4 text-[14px] font-semibold text-primary-foreground"
                >
                  清除筛选
                </button>
              ) : undefined
            }
          />
        ) : (
          groups.map((g) => (
            <section key={g.key} className="mb-3">
              <div className="flex items-center justify-between px-4 py-2">
                <h2 className="text-[12px] font-medium text-muted">{formatDayHeading(g.ts)}</h2>
                <span className="text-[12px] tabular-nums text-muted">
                  {g.expense > 0 ? `支 ${formatFen(g.expense)}` : ""}
                  {g.income > 0 ? `  收 ${formatFen(g.income)}` : ""}
                </span>
              </div>
              <div className="system-list mx-4 overflow-hidden">
                {g.items.map((tx, index) => (
                  <div key={tx.id} className={cn(index > 0 && "border-t border-divider/70")}>
                    <TxRow
                      tx={tx}
                      accounts={accounts}
                      categories={categories}
                      showTime
                      onClick={() => push({ name: "detail", id: tx.id })}
                    />
                  </div>
                ))}
              </div>
            </section>
          ))
        )}
      </div>
    </div>
  );
}

function SummaryCell({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="px-2 py-2.5">
      <p className="text-[11px] text-muted">{label}</p>
      <p className={cn("mt-0.5 truncate text-[13px] font-semibold tabular-nums", tone)}>{value}</p>
    </div>
  );
}

function groupByDay(list: Transaction[]) {
  const map = new Map<
    string,
    { key: string; ts: number; items: Transaction[]; income: number; expense: number }
  >();
  for (const tx of list) {
    const d = new Date(tx.occurredAt);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    const cur = map.get(key) ?? {
      key,
      ts: startOfDay(tx.occurredAt),
      items: [],
      income: 0,
      expense: 0,
    };
    cur.items.push(tx);
    if (tx.type === "INCOME") cur.income += tx.amountFen;
    if (tx.type === "EXPENSE") cur.expense += tx.amountFen;
    map.set(key, cur);
  }
  return [...map.values()];
}
