import { toast } from "sonner";
import { Download, FileJson, FileSpreadsheet, RotateCcw, Upload } from "lucide-react";
import { GhostButton, PrimaryButton, Row, SectionLabel, TopBar } from "../ui";
import { confirmAction } from "@/lib/ledger/confirm";
import { useLedgerStore, snapshotFromStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import {
  downloadText,
  parseBackupJson,
  parseCsvTransactions,
  pickLocalFile,
  snapshotToBackup,
  snapshotToCsv,
} from "@/lib/ledger/export";
import { formatDateTime, monthKey } from "@/lib/ledger/dates";

export function DataScreen() {
  const pop = useNavStore((s) => s.pop);
  const push = useNavStore((s) => s.push);
  const setImportPreview = useNavStore((s) => s.setImportPreview);
  const setRestorePreview = useNavStore((s) => s.setRestorePreview);
  const loadDemo = useLedgerStore((s) => s.loadDemo);
  const resetLocalData = useLedgerStore((s) => s.resetLocalData);
  const resetTo = useNavStore((s) => s.resetTo);

  async function exportJson() {
    const bak = snapshotToBackup(snapshotFromStore());
    downloadText(`小账本备份-${monthKey()}.json`, JSON.stringify(bak, null, 2), "application/json");
    toast.success("已导出 JSON。文件含完整财务记录，请妥善保存。");
  }

  async function exportCsv() {
    downloadText(
      `小账本账单-${monthKey()}.csv`,
      snapshotToCsv(snapshotFromStore()),
      "text/csv;charset=utf-8",
    );
    toast.success("已导出 CSV，适合阅读和分析。");
  }

  async function importFile() {
    const file = await pickLocalFile(".csv,text/csv");
    if (!file) return;
    try {
      const text = await file.text();
      const { rows, errors } = parseCsvTransactions(text, snapshotFromStore());
      setImportPreview({ source: "csv", filename: file.name, transactions: rows, errors });
      push({ name: "import-preview" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "解析失败");
    }
  }
  async function restoreFile() {
    const file = await pickLocalFile(".json,application/json");
    if (!file) return;
    try {
      const backup = parseBackupJson(await file.text());
      setRestorePreview({ filename: file.name, backup });
      push({ name: "restore-preview" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "解析失败");
    }
  }

  return (
    <div className="flex h-full flex-col">
      <TopBar title="数据管理" onBack={pop} />
      <div className="screen-scroll pb-8">
        <p className="px-4 pb-1 text-[12px] leading-relaxed text-muted">
          备份是你主动导出的本地文件，不是云同步。导出文件包含完整财务记录。
        </p>
        <SectionLabel>导出</SectionLabel>
        <div className="system-list mx-4 overflow-hidden">
          <Row
            icon={FileJson}
            title="导出 JSON 备份"
            hint="完整恢复格式，带版本号"
            onClick={exportJson}
          />
          <Row icon={FileSpreadsheet} title="导出 CSV" hint="便于阅读和分析" onClick={exportCsv} />
        </div>
        <SectionLabel>导入与恢复</SectionLabel>
        <div className="system-list mx-4 overflow-hidden">
          <Row
            icon={Upload}
            title="导入 CSV 账单"
            hint="先预览，再追加到当前账本"
            onClick={importFile}
          />
          <Row
            icon={Download}
            title="恢复 JSON 备份"
            hint="完整覆盖当前账本，需二次确认"
            onClick={restoreFile}
          />
        </div>
        <SectionLabel>其他</SectionLabel>
        <div className="system-list mx-4 overflow-hidden">
          <Row
            icon={FileJson}
            title="载入示例数据"
            hint="覆盖当前账本为演示内容"
            onClick={async () => {
              const ok = await confirmAction({
                title: "载入示例账本？",
                body: "当前本地数据会被示例账单替换，适合先熟悉功能。",
                confirmLabel: "载入示例",
                danger: true,
              });
              if (!ok) return;
              loadDemo();
              toast.success("已载入示例");
              pop();
            }}
          />
          <Row
            icon={RotateCcw}
            title="清空本地数据"
            hint="回到首次启动"
            danger
            onClick={async () => {
              const ok = await confirmAction({
                title: "清空全部数据？",
                body: "账户、账单、预算都会从本机删除，且无法撤销。请确认已导出备份。",
                confirmLabel: "清空",
                danger: true,
              });
              if (!ok) return;
              resetLocalData();
              resetTo({ name: "welcome" });
              toast.success("已清空");
            }}
          />
        </div>
      </div>
    </div>
  );
}

export function ImportPreviewScreen() {
  const pop = useNavStore((s) => s.pop);
  const preview = useNavStore((s) => s.importPreview);
  const setImportPreview = useNavStore((s) => s.setImportPreview);
  const importTransactions = useLedgerStore((s) => s.importTransactions);

  if (!preview) {
    return (
      <div className="flex h-full flex-col">
        <TopBar title="导入预览" onBack={pop} />
        <p className="px-4 py-8 text-sm text-muted">没有待导入的文件。</p>
      </div>
    );
  }

  const count =
    preview.source === "json" && preview.backup
      ? preview.backup.transactions.length
      : preview.transactions.length;

  return (
    <div className="flex h-full flex-col">
      <TopBar title="导入预览" onBack={pop} />
      <div className="screen-scroll px-4 pb-8">
        <div className="rounded-2xl bg-surface p-4 hairline">
          <p className="text-[15px] font-semibold">{preview.filename}</p>
          <p className="mt-2 text-[13px] text-muted">
            {preview.source === "json" ? "JSON 备份" : "CSV 账单"} · 将新增 {count} 笔交易
            {preview.backup ? ` · ${preview.backup.accounts.length} 个账户` : ""}
          </p>
          {preview.backup ? (
            <p className="mt-1 text-[12px] text-muted">
              导出时间 {formatDateTime(preview.backup.exportedAt)}
            </p>
          ) : null}
        </div>
        {preview.errors.length > 0 ? (
          <div className="mt-3 rounded-2xl bg-warning-soft p-3 text-[12px] text-warning">
            {preview.errors.slice(0, 6).map((e) => (
              <p key={e}>{e}</p>
            ))}
            {preview.errors.length > 6 ? <p>还有 {preview.errors.length - 6} 条…</p> : null}
          </div>
        ) : null}
        <p className="mt-4 text-[13px] leading-relaxed text-muted">
          导入会把解析出的账单追加到当前账本，不会清空已有数据。若要完全覆盖，请用「恢复备份」。
        </p>
        <div className="mt-6 space-y-2">
          <PrimaryButton
            disabled={count === 0}
            onClick={() => {
              if (preview.source === "csv") importTransactions(preview.transactions);
              else if (preview.backup) importTransactions(preview.backup.transactions);
              setImportPreview(null);
              toast.success("已导入");
              pop();
            }}
          >
            确认导入
          </PrimaryButton>
          <GhostButton onClick={pop}>返回</GhostButton>
        </div>
      </div>
    </div>
  );
}

export function RestorePreviewScreen() {
  const pop = useNavStore((s) => s.pop);
  const preview = useNavStore((s) => s.restorePreview);
  const setRestorePreview = useNavStore((s) => s.setRestorePreview);
  const restoreBackup = useLedgerStore((s) => s.restoreBackup);

  if (!preview) {
    return (
      <div className="flex h-full flex-col">
        <TopBar title="恢复备份" onBack={pop} />
        <p className="px-4 py-8 text-sm text-muted">没有待恢复的文件。</p>
      </div>
    );
  }

  const b = preview.backup;

  return (
    <div className="flex h-full flex-col">
      <TopBar title="恢复备份" onBack={pop} />
      <div className="screen-scroll px-4 pb-8">
        <div className="rounded-2xl bg-expense-soft p-4">
          <p className="text-[14px] font-semibold text-expense">将覆盖当前账本</p>
          <p className="mt-1 text-[13px] leading-relaxed text-muted">
            账户、分类、账单、预算和设置都会被备份文件替换。此操作不能撤销。
          </p>
        </div>
        <div className="mt-3 rounded-2xl bg-surface p-4 hairline text-[14px]">
          <p>文件 {preview.filename}</p>
          <p className="mt-1 text-muted">导出时间 {formatDateTime(b.exportedAt)}</p>
          <p className="mt-2">交易 {b.transactions.length} 笔</p>
          <p>账户 {b.accounts.length} 个</p>
          <p>分类 {b.categories.length} 个</p>
          <p>预算 {b.budgets.length} 条</p>
        </div>
        <div className="mt-6 space-y-2">
          <PrimaryButton
            tone="expense"
            onClick={async () => {
              const ok = await confirmAction({
                title: "确认覆盖全部数据？",
                body: `将用 ${b.transactions.length} 笔交易、${b.accounts.length} 个账户替换当前账本。`,
                confirmLabel: "确认恢复",
                danger: true,
              });
              if (!ok) return;
              restoreBackup(b);
              setRestorePreview(null);
              toast.success("已恢复");
              pop();
            }}
          >
            确认恢复
          </PrimaryButton>
          <GhostButton onClick={pop}>取消</GhostButton>
        </div>
      </div>
    </div>
  );
}
