import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartNoAxesCombined } from "lucide-react";
import { EmptyState, TopBar } from "../ui";
import { MonthSwitcher } from "../chrome";
import { useLedgerStore } from "@/lib/ledger/store";
import { useNavStore } from "@/lib/ledger/nav";
import { formatFen, fenToYuanString } from "@/lib/ledger/money";
import { formatMonthTitle, shiftMonth } from "@/lib/ledger/dates";
import { categoryRank, monthCompare, monthTotals } from "@/lib/ledger/formulas";
import { categoryIcon } from "@/lib/ledger/icons";
import { cn } from "@/lib/utils";

export function StatsScreen() {
  const transactions = useLedgerStore((s) => s.transactions);
  const categories = useLedgerStore((s) => s.categories);
  const month = useNavStore((s) => s.month);
  const setMonth = useNavStore((s) => s.setMonth);
  const push = useNavStore((s) => s.push);

  const totals = monthTotals(transactions, month);
  const prev = monthTotals(transactions, shiftMonth(month, -1));
  const compare = monthCompare(transactions, month, 5);
  const rank = categoryRank(transactions, month, "EXPENSE", categories);
  const empty = totals.income === 0 && totals.expense === 0;

  const chartData = compare.map((row) => ({
    name: `${Number(row.month.slice(5))}月`,
    收入: Number(fenToYuanString(row.income)),
    支出: Number(fenToYuanString(row.expense)),
    incomeLabel: formatFen(row.income),
    expenseLabel: formatFen(row.expense),
  }));

  return (
    <div className="flex h-full flex-col">
      <TopBar title="统计" />
      <div className="px-4">
        <MonthSwitcher
          month={month}
          label={formatMonthTitle(month)}
          onPrev={() => setMonth(shiftMonth(month, -1))}
          onNext={() => setMonth(shiftMonth(month, 1))}
        />
      </div>
      <div className="screen-scroll px-4 pb-6">
        {empty ? (
          <EmptyState
            icon={ChartNoAxesCombined}
            title="本月暂无数据"
            body="有账单之后，这里会显示收支、趋势和分类排行，不会编造图表。"
          />
        ) : (
          <>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <div className="rounded-2xl bg-income-soft p-3.5">
                <p className="text-[12px] text-income">收入</p>
                <p className="mt-1 text-[20px] font-semibold tabular-nums text-income">
                  {formatFen(totals.income)}
                </p>
              </div>
              <div className="rounded-2xl bg-expense-soft p-3.5">
                <p className="text-[12px] text-expense">支出</p>
                <p className="mt-1 text-[20px] font-semibold tabular-nums text-expense">
                  {formatFen(totals.expense)}
                </p>
              </div>
            </div>
            <p className="mt-2 px-1 text-[12px] text-muted">
              结余 {formatFen(totals.surplus, { sign: true })} · 转账不计入收支
            </p>

            <h2 className="mt-5 text-[15px] font-semibold">近半年对比</h2>
            <div className="mt-2 h-48 rounded-2xl bg-surface p-2 hairline">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} barGap={2}>
                  <CartesianGrid vertical={false} stroke="var(--color-divider)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: "var(--color-muted)" }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip
                    cursor={{ fill: "var(--color-surface-2)" }}
                    content={({ payload, label }) => {
                      if (!payload?.length) return null;
                      const row = payload[0]?.payload as (typeof chartData)[number];
                      return (
                        <div className="rounded-lg bg-surface px-3 py-2 text-[12px] shadow-[var(--shadow-card)]">
                          <p className="font-medium">{label}</p>
                          <p className="text-income">收入 {row.incomeLabel}</p>
                          <p className="text-expense">支出 {row.expenseLabel}</p>
                        </div>
                      );
                    }}
                  />
                  <Bar dataKey="收入" fill="var(--color-income)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="支出" fill="var(--color-expense)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-1 flex gap-4 px-1 text-[11px] text-muted">
              <span className="inline-flex items-center gap-1">
                <i className="inline-block size-2 rounded-sm bg-income" /> 收入
              </span>
              <span className="inline-flex items-center gap-1">
                <i className="inline-block size-2 rounded-sm bg-expense" /> 支出
              </span>
            </div>

            <h2 className="mt-5 text-[15px] font-semibold">月度对比</h2>
            <div className="mt-2 rounded-2xl bg-surface p-4 hairline">
              <CompareLine label="收入" now={totals.income} was={prev.income} tone="text-income" />
              <CompareLine label="支出" now={totals.expense} was={prev.expense} tone="text-expense" />
            </div>

            <h2 className="mt-5 text-[15px] font-semibold">支出分类排行</h2>
            <div className="mt-2 overflow-hidden rounded-2xl bg-surface hairline">
              {rank.rows.length === 0 ? (
                <p className="px-4 py-8 text-center text-[13px] text-muted">本月没有支出分类</p>
              ) : (
                rank.rows.map((row) => {
                  const Icon = categoryIcon(row.category?.icon ?? "more");
                  return (
                    <button
                      key={row.categoryId}
                      type="button"
                      onClick={() => push({ name: "analysis", categoryId: row.categoryId })}
                      className="flex w-full items-center gap-3 px-4 py-3 text-left"
                    >
                      <span className="flex size-9 items-center justify-center rounded-xl bg-expense-soft text-expense">
                        <Icon className="size-4" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex justify-between text-[14px]">
                          <span className="font-medium">{row.category?.name ?? "未分类"}</span>
                          <span className="tabular-nums">{formatFen(row.amountFen)}</span>
                        </span>
                        <span className="mt-1 block h-1.5 overflow-hidden rounded-full bg-surface-2">
                          <span
                            className="block h-full rounded-full bg-expense"
                            style={{ width: `${Math.max(4, row.percent * 100)}%` }}
                          />
                        </span>
                        <span className="mt-1 block text-[11px] text-muted">
                          占比 {(row.percent * 100).toFixed(1)}%
                        </span>
                      </span>
                    </button>
                  );
                })
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function CompareLine({
  label,
  now,
  was,
  tone,
}: {
  label: string;
  now: number;
  was: number;
  tone: string;
}) {
  const diff = now - was;
  return (
    <div className="flex items-center justify-between py-1.5 text-[13px]">
      <span className="text-muted">{label}</span>
      <span className="tabular-nums">
        <span className={cn("font-medium", tone)}>{formatFen(now)}</span>
        <span className="ml-2 text-[12px] text-muted">
          上月 {formatFen(was)}
          {was === 0 && now === 0
            ? ""
            : ` · ${diff >= 0 ? "多" : "少"} ${formatFen(Math.abs(diff), { symbol: true })}`}
        </span>
      </span>
    </div>
  );
}
