import { useMemo, useState, type ReactNode } from "react";
import { Calendar, NotebookPen, Wallet, ArrowLeftRight, Delete } from "lucide-react";
import { toast } from "sonner";
import { PrimaryButton, TopBar } from "../ui";
import { useNavStore } from "@/lib/ledger/nav";
import { useLedgerStore } from "@/lib/ledger/store";
import { appendAmountKey, fenToYuanString, isValidPositiveAmount, parseYuanInputToFen } from "@/lib/ledger/money";
import { formatDateTime, toDatetimeLocalValue, fromDatetimeLocalValue } from "@/lib/ledger/dates";
import { categoryIcon } from "@/lib/ledger/icons";
import type { Account } from "@/lib/ledger/types";
import type { TransactionType } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "back"] as const;

function fenToAmountInput(fen: number): string {
  const s = fenToYuanString(fen);
  if (s.endsWith(".00")) return s.slice(0, -3);
  if (s.endsWith("0") && s.includes(".")) return s.slice(0, -1);
  return s;
}

export function RecordScreen({ type, editId }: { type: TransactionType; editId?: string }) {
  const pop = useNavStore((s) => s.pop);
  const push = useNavStore((s) => s.push);
  const allAccounts = useLedgerStore((s) => s.accounts);
  const accounts = allAccounts.filter((a) => a.status === "ACTIVE");
  const categories = useLedgerStore((s) => s.categories);
  const settings = useLedgerStore((s) => s.settings);
  const existing = useLedgerStore((s) => s.transactions.find((t) => t.id === editId));
  const addTransaction = useLedgerStore((s) => s.addTransaction);
  const updateTransaction = useLedgerStore((s) => s.updateTransaction);

  const initial = useMemo(() => {
    if (existing) {
      return {
        amount: fenToAmountInput(existing.amountFen),
        accountId: existing.accountId ?? "",
        categoryId: existing.categoryId ?? "",
        fromAccountId: existing.fromAccountId ?? "",
        toAccountId: existing.toAccountId ?? "",
        note: existing.note,
        occurredAt: existing.occurredAt,
      };
    }
    const lastCat =
      type === "INCOME" ? settings.lastUsedIncomeCategoryId : settings.lastUsedExpenseCategoryId;
    const activeCats = categories.filter((c) => c.type === type && c.status === "ACTIVE");
    return {
      amount: "",
      accountId: settings.lastUsedAccountId ?? accounts[0]?.id ?? "",
      categoryId: activeCats.find((c) => c.id === lastCat)?.id ?? activeCats[0]?.id ?? "",
      fromAccountId: accounts[0]?.id ?? "",
      toAccountId: accounts[1]?.id ?? accounts[0]?.id ?? "",
      note: "",
      occurredAt: Date.now(),
    };
  }, [existing, type, settings, categories, accounts]);

  const [amount, setAmount] = useState(initial.amount);
  const [accountId, setAccountId] = useState(initial.accountId);
  const [categoryId, setCategoryId] = useState(initial.categoryId);
  const [fromAccountId, setFromAccountId] = useState(initial.fromAccountId);
  const [toAccountId, setToAccountId] = useState(initial.toAccountId);
  const [note, setNote] = useState(initial.note);
  const [occurredAt, setOccurredAt] = useState(initial.occurredAt);
  const [noteOpen, setNoteOpen] = useState(Boolean(initial.note));

  const title =
    editId != null
      ? "编辑账单"
      : type === "INCOME"
        ? "记收入"
        : type === "TRANSFER"
          ? "转账"
          : "记支出";
  const amountColor =
    type === "INCOME" ? "text-income" : type === "EXPENSE" ? "text-expense" : "text-primary";
  const canSave =
    isValidPositiveAmount(amount) &&
    (type === "TRANSFER"
      ? Boolean(fromAccountId && toAccountId && fromAccountId !== toAccountId)
      : Boolean(accountId && categoryId));

  const activeCats = categories
    .filter((c) => c.type === (type === "INCOME" ? "INCOME" : "EXPENSE") && c.status === "ACTIVE")
    .sort((a, b) => a.sortOrder - b.sortOrder);

  function save() {
    try {
      const payload = {
        type,
        amountFen: parseYuanInputToFen(amount),
        note: note.trim(),
        occurredAt,
        accountId: type === "TRANSFER" ? undefined : accountId,
        categoryId: type === "TRANSFER" ? undefined : categoryId,
        fromAccountId: type === "TRANSFER" ? fromAccountId : undefined,
        toAccountId: type === "TRANSFER" ? toAccountId : undefined,
      };
      if (editId) updateTransaction(editId, payload);
      else addTransaction(payload);
      toast.success("已记录");
      pop();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "保存失败");
    }
  }

  return (
    <div className="flex h-full flex-col bg-background">
      <TopBar title={title} onBack={pop} />
      <div className="flex min-h-0 flex-1 flex-col px-4">
        <div className="mx-1 mb-2 flex flex-1 flex-col items-center justify-center rounded-[24px] bg-surface py-3 shadow-[var(--shadow-card)]">
          <p className="text-[12px] text-muted">金额（元）</p>
          <p className={cn("amount-display mt-1 max-w-full truncate text-[36px] font-bold tabular-nums leading-none", amountColor)}>
            ¥{amount || "0"}
          </p>
        </div>

        {type !== "TRANSFER" ? (
          <div className="mb-2">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[12px] font-medium text-muted">分类</span>
              <button
                type="button"
                className="text-[12px] text-primary"
                onClick={() =>
                  push({ name: "categories", kind: type === "INCOME" ? "INCOME" : "EXPENSE", pick: true })
                }
              >
                管理
              </button>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {activeCats.map((c) => {
                const Icon = categoryIcon(c.icon);
                const active = c.id === categoryId;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setCategoryId(c.id)}
                    className={cn(
                      "flex h-[68px] w-[74px] shrink-0 flex-col items-center justify-center gap-1 rounded-2xl border transition-all",
                      active ? "border-primary bg-primary text-primary-foreground shadow-sm" : "border-transparent bg-surface-2 text-foreground",
                    )}
                  >
                    <Icon className="size-5" strokeWidth={1.7} />
                    <span className="text-[12px]">{c.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="mb-3 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
            <AccountSelect label="转出" value={fromAccountId} onChange={setFromAccountId} accounts={accounts} />
            <ArrowLeftRight className="size-4 text-muted" />
            <AccountSelect label="转入" value={toAccountId} onChange={setToAccountId} accounts={accounts} />
          </div>
        )}

        <div className="mb-2 flex gap-2">
          {type !== "TRANSFER" ? (
            <Picker
              icon={Wallet}
              label={accounts.find((a) => a.id === accountId)?.name ?? "账户"}
              extra={
                <select
                  aria-label="选择账户"
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value)}
                  className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                >
                  {accounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
              }
            />
          ) : null}
          <Picker
            icon={Calendar}
            label={formatDateTime(occurredAt)}
            extra={
              <input
                type="datetime-local"
                className="absolute inset-0 cursor-pointer opacity-0"
                value={toDatetimeLocalValue(occurredAt)}
                onChange={(e) => setOccurredAt(fromDatetimeLocalValue(e.target.value))}
              />
            }
          />
          <Picker icon={NotebookPen} label={note ? "已填备注" : "备注"} onClick={() => setNoteOpen((v) => !v)} />
        </div>
        {noteOpen ? (
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="写一句备注，可搜索"
            className="mb-2 h-11 w-full rounded-xl bg-surface-2 px-3 text-[14px] outline-none"
          />
        ) : null}

        {type === "TRANSFER" && fromAccountId === toAccountId ? (
          <p className="mb-2 text-center text-[12px] text-expense">转出与转入不能相同</p>
        ) : null}

        <div className="grid grid-cols-3 gap-2 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          {KEYS.map((k) => (
            <button
              key={k}
              type="button"
              className="keypad-btn"
              onClick={() => setAmount((v) => appendAmountKey(v, k))}
            >
              {k === "back" ? <Delete className="mx-auto size-5" /> : k}
            </button>
          ))}
          <PrimaryButton
            className="col-span-3"
            disabled={!canSave}
            tone={type === "INCOME" ? "income" : type === "EXPENSE" ? "expense" : "primary"}
            onClick={save}
          >
            保存
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
}

function Picker({
  icon: Icon,
  label,
  onClick,
  extra,
}: {
  icon: typeof Wallet;
  label: string;
  onClick?: () => void;
  extra?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="relative flex min-h-11 min-w-0 flex-1 items-center justify-center gap-1.5 rounded-2xl bg-surface-2 px-2 text-[12px] text-foreground"
    >
      <Icon className="size-3.5 shrink-0 text-muted" />
      <span className="truncate">{label}</span>
      {extra}
    </button>
  );
}

function AccountSelect({
  label,
  value,
  onChange,
  accounts,
}: {
  label: string;
  value: string;
  onChange: (id: string) => void;
  accounts: Account[];
}) {
  return (
    <label className="block rounded-xl bg-surface-2 p-2.5">
      <span className="text-[11px] text-muted">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-0.5 w-full bg-transparent text-[14px] font-medium outline-none"
      >
        {accounts.map((a) => (
          <option key={a.id} value={a.id}>
            {a.name}
          </option>
        ))}
      </select>
    </label>
  );
}
