import type { ReactNode } from "react";
import { BarChart3, BookOpen, Home, Plus, ArrowLeftRight, Minus, UserRound, X } from "lucide-react";
import { useNavStore, type TabName } from "@/lib/ledger/nav";
import { useConfirmStore } from "@/lib/ledger/confirm";
import { cn } from "@/lib/utils";

const TABS: { id: TabName; label: string; icon: typeof Home }[] = [
  { id: "home", label: "首页", icon: Home },
  { id: "bills", label: "账单", icon: BookOpen },
  { id: "stats", label: "统计", icon: BarChart3 },
  { id: "me", label: "我的", icon: UserRound },
];

export function BottomNav() {
  const tab = useNavStore((s) => s.tab);
  const goTab = useNavStore((s) => s.goTab);
  const open = useNavStore((s) => s.fabOpen);
  const setOpen = useNavStore((s) => s.setFabOpen);

  const renderTab = (t: (typeof TABS)[number]) => {
    const active = tab === t.id;
    const Icon = t.icon;
    return (
      <button
        key={t.id}
        type="button"
        onClick={() => goTab(t.id)}
        className={cn(
          "pressable flex min-w-0 flex-col items-center justify-center gap-0.5 text-[10px] font-medium",
          active ? "text-primary" : "text-muted",
        )}
      >
        <span
          className={cn(
            "flex h-7 min-w-9 items-center justify-center rounded-lg px-2",
            active && "nav-active-pill",
          )}
        >
          <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
        </span>
        {t.label}
      </button>
    );
  };

  return (
    <nav className="bottom-nav bottom-nav-glass z-20 shrink-0 backdrop-blur-xl">
      <div className="grid h-[58px] grid-cols-5 px-1">
        {renderTab(TABS[0])}
        {renderTab(TABS[1])}
        <button
          type="button"
          aria-label={open ? "关闭记账菜单" : "记一笔"}
          onClick={() => setOpen(!open)}
          className="pressable relative flex flex-col items-center justify-end pb-1 text-[10px] font-medium text-primary"
        >
          <span
            className={cn(
              "absolute -top-3 flex size-12 items-center justify-center rounded-2xl border-4 border-surface text-white shadow-[var(--shadow-float)]",
              open ? "bg-foreground" : "bg-primary",
            )}
          >
            {open ? <X className="size-5" /> : <Plus className="size-6" strokeWidth={2.4} />}
          </span>
          记账
        </button>
        {renderTab(TABS[2])}
        {renderTab(TABS[3])}
      </div>
    </nav>
  );
}

export function RecordFab() {
  const open = useNavStore((s) => s.fabOpen);
  const setOpen = useNavStore((s) => s.setFabOpen);
  const push = useNavStore((s) => s.push);

  if (!open) return null;

  const choose = (type: "EXPENSE" | "INCOME" | "TRANSFER") => {
    setOpen(false);
    push({ name: "record", type });
  };

  return (
    <div
      className="sheet-backdrop absolute inset-0 z-30 flex items-end bg-foreground/25 backdrop-blur-[2px]"
      onClick={() => setOpen(false)}
    >
      <section
        aria-label="快速记账"
        className="sheet-panel mb-[calc(58px+env(safe-area-inset-bottom))] w-full rounded-t-2xl bg-surface px-4 pb-5 pt-4 shadow-[0_-16px_40px_-24px_rgb(24_24_26/.45)]"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-[18px] font-semibold">记一笔</h2>
            <p className="mt-0.5 text-[12px] text-muted">选择账目类型后填写金额</p>
          </div>
          <button
            type="button"
            aria-label="关闭"
            className="pressable flex size-9 items-center justify-center rounded-lg bg-surface-2"
            onClick={() => setOpen(false)}
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <FabAction
            label="支出"
            hint="消费付款"
            className="bg-expense-soft text-expense"
            icon={<Minus className="size-5" />}
            onClick={() => choose("EXPENSE")}
          />
          <FabAction
            label="收入"
            hint="工资收款"
            className="bg-income-soft text-income"
            icon={<Plus className="size-5" />}
            onClick={() => choose("INCOME")}
          />
          <FabAction
            label="转账"
            hint="账户互转"
            className="bg-primary-soft text-primary"
            icon={<ArrowLeftRight className="size-5" />}
            onClick={() => choose("TRANSFER")}
          />
        </div>
      </section>
    </div>
  );
}

function FabAction({
  label,
  hint,
  className,
  icon,
  onClick,
}: {
  label: string;
  hint: string;
  className: string;
  icon: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="pressable flex min-h-[92px] flex-col items-center justify-center rounded-xl bg-surface-2 px-2"
    >
      <span className={cn("flex size-10 items-center justify-center rounded-xl", className)}>
        {icon}
      </span>
      <span className="mt-2 text-[14px] font-semibold text-foreground">{label}</span>
      <span className="mt-0.5 text-[10px] text-muted">{hint}</span>
    </button>
  );
}

export function ConfirmHost() {
  const s = useConfirmStore();
  if (!s.open) return null;
  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:items-center">
      <div className="w-full max-w-sm rounded-2xl bg-surface p-5 shadow-[var(--shadow-card)]">
        <h2 className="text-[17px] font-semibold">{s.title}</h2>
        <p className="mt-2 text-[14px] leading-relaxed text-muted">{s.body}</p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => s.close(false)}
            className="h-11 rounded-xl bg-surface-2 text-[14px] font-medium"
          >
            {s.cancelLabel}
          </button>
          <button
            type="button"
            onClick={() => s.close(true)}
            className={cn(
              "h-11 rounded-xl text-[14px] font-semibold text-primary-foreground",
              s.danger ? "bg-expense" : "bg-primary",
            )}
          >
            {s.confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

export function MonthSwitcher({
  month,
  onPrev,
  onNext,
  label,
  compact = false,
}: {
  month: string;
  onPrev: () => void;
  onNext: () => void;
  label: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-center",
        compact ? "gap-0 rounded-lg bg-surface px-0.5 hairline" : "gap-2",
      )}
    >
      <button
        type="button"
        aria-label="上月"
        onClick={onPrev}
        className={cn(
          "pressable flex items-center justify-center rounded-lg text-muted",
          compact ? "size-8" : "size-9",
        )}
      >
        <svg
          viewBox="0 0 24 24"
          className="size-5"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
        >
          <path d="M15 6l-6 6 6 6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      <span
        className={cn(
          "text-center font-semibold tabular-nums",
          compact ? "min-w-[5.5rem] text-[12px]" : "min-w-[7.5rem] text-[15px]",
        )}
      >
        {label}
      </span>
      <button
        type="button"
        aria-label="下月"
        onClick={onNext}
        className={cn(
          "pressable flex items-center justify-center rounded-lg text-muted",
          compact ? "size-8" : "size-9",
        )}
      >
        <svg
          viewBox="0 0 24 24"
          className="size-5"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
        >
          <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
    </div>
  );
}

export function ProgressBar({ ratio, tone }: { ratio: number; tone: "ok" | "warn" | "over" }) {
  const width = Math.min(100, Math.max(0, ratio * 100));
  const color = tone === "over" ? "bg-expense" : tone === "warn" ? "bg-warning" : "bg-primary";
  return (
    <div className="progress-track">
      <div className={cn("progress-fill", color)} style={{ width: `${width}%` }} />
    </div>
  );
}
