export function nid(prefix: string): string {
  const raw =
    globalThis.crypto?.randomUUID?.().replace(/-/g, "") ??
    `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}_${raw.slice(0, 16)}`;
}
