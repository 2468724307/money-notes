import type { Account, BillFilter, Budget, Category, Transaction } from "./types";
import { monthRange, dayKey, startOfDay, shiftMonth } from "./dates";
import { parseYuanInputToFen } from "./money";

export function accountBalanceFen(account: Account, transactions: Transaction[]): number {
  let bal = account.openingBalanceFen;
  for (const tx of transactions) {
    if (tx.type === "EXPENSE" && tx.accountId === account.id) bal -= tx.amountFen;
    else if (tx.type === "INCOME" && tx.accountId === account.id) bal += tx.amountFen;
    else if (tx.type === "TRANSFER") {
      if (tx.fromAccountId === account.id) bal -= tx.amountFen;
      if (tx.toAccountId === account.id) bal += tx.amountFen;
    }
  }
  return bal;
}

export function totalBalanceFen(accounts: Account[], transactions: Transaction[]): number {
  return accounts.reduce((sum, a) => sum + accountBalanceFen(a, transactions), 0);
}

export function inMonth(tx: Transaction, month: string): boolean {
  const { start, end } = monthRange(month);
  return tx.occurredAt >= start && tx.occurredAt <= end;
}

export function monthTotals(transactions: Transaction[], month: string) {
  let income = 0;
  let expense = 0;
  for (const tx of transactions) {
    if (!inMonth(tx, month)) continue;
    if (tx.type === "INCOME") income += tx.amountFen;
    else if (tx.type === "EXPENSE") expense += tx.amountFen;
  }
  return { income, expense, surplus: income - expense };
}

export function budgetUsedFen(
  transactions: Transaction[],
  month: string,
  categoryId: string | null,
): number {
  let used = 0;
  for (const tx of transactions) {
    if (tx.type !== "EXPENSE") continue;
    if (!inMonth(tx, month)) continue;
    if (categoryId && tx.categoryId !== categoryId) continue;
    used += tx.amountFen;
  }
  return used;
}

export function budgetStatus(used: number, amount: number): "ok" | "warn" | "over" {
  if (amount <= 0) return used > 0 ? "over" : "ok";
  const ratio = used / amount;
  if (ratio > 1) return "over";
  if (ratio >= 0.8) return "warn";
  return "ok";
}

export function categoryRank(
  transactions: Transaction[],
  month: string,
  type: "EXPENSE" | "INCOME",
  categories: Category[],
) {
  const map = new Map<string, number>();
  let total = 0;
  for (const tx of transactions) {
    if (tx.type !== type || !inMonth(tx, month) || !tx.categoryId) continue;
    map.set(tx.categoryId, (map.get(tx.categoryId) ?? 0) + tx.amountFen);
    total += tx.amountFen;
  }
  const rows = [...map.entries()]
    .map(([categoryId, amountFen]) => ({
      categoryId,
      amountFen,
      percent: total > 0 ? amountFen / total : 0,
      category: categories.find((c) => c.id === categoryId),
    }))
    .sort((a, b) => b.amountFen - a.amountFen);
  return { total, rows };
}

export function dailySeries(
  transactions: Transaction[],
  month: string,
  type: "EXPENSE" | "INCOME",
): { day: string; label: string; amountFen: number }[] {
  const { start, end } = monthRange(month);
  const buckets = new Map<string, number>();
  for (let t = start; t <= end; t += 24 * 60 * 60 * 1000) {
    buckets.set(dayKey(t), 0);
  }
  // Ensure last day exists even if DST-ish gaps
  buckets.set(dayKey(end), buckets.get(dayKey(end)) ?? 0);

  for (const tx of transactions) {
    if (tx.type !== type || !inMonth(tx, month)) continue;
    const k = dayKey(tx.occurredAt);
    buckets.set(k, (buckets.get(k) ?? 0) + tx.amountFen);
  }
  return [...buckets.entries()].map(([day, amountFen]) => ({
    day,
    label: String(Number(day.slice(8))),
    amountFen,
  }));
}

export function monthCompare(transactions: Transaction[], month: string, lookback = 5) {
  const months: string[] = [];
  for (let i = lookback; i >= 0; i--) months.push(shiftMonth(month, -i));
  return months.map((m) => ({ month: m, ...monthTotals(transactions, m) }));
}

export function filterTransactions(
  transactions: Transaction[],
  filter: BillFilter,
  accounts: Account[],
  categories: Category[],
): Transaction[] {
  const kw = filter.keyword.trim().toLowerCase();
  const minFen =
    filter.amountMinYuan.trim() === "" ? null : parseYuanInputToFen(filter.amountMinYuan);
  const maxFen =
    filter.amountMaxYuan.trim() === "" ? null : parseYuanInputToFen(filter.amountMaxYuan);
  const from = filter.dateFrom ? startOfDay(new Date(filter.dateFrom).getTime()) : null;
  const to = filter.dateTo
    ? startOfDay(new Date(filter.dateTo).getTime()) + 24 * 60 * 60 * 1000 - 1
    : null;

  return transactions.filter((tx) => {
    if (filter.type !== "ALL" && tx.type !== filter.type) return false;
    if (filter.categoryId && tx.categoryId !== filter.categoryId) return false;
    if (filter.accountId) {
      const hit =
        tx.accountId === filter.accountId ||
        tx.fromAccountId === filter.accountId ||
        tx.toAccountId === filter.accountId;
      if (!hit) return false;
    }
    if (from !== null && tx.occurredAt < from) return false;
    if (to !== null && tx.occurredAt > to) return false;
    if (minFen !== null && tx.amountFen < minFen) return false;
    if (maxFen !== null && tx.amountFen > maxFen) return false;
    if (kw) {
      const cat = categories.find((c) => c.id === tx.categoryId)?.name ?? "";
      const acc =
        accounts.find((a) => a.id === tx.accountId)?.name ??
        [
          accounts.find((a) => a.id === tx.fromAccountId)?.name,
          accounts.find((a) => a.id === tx.toAccountId)?.name,
        ]
          .filter(Boolean)
          .join(" ");
      const blob = `${tx.note} ${cat} ${acc}`.toLowerCase();
      if (!blob.includes(kw)) return false;
    }
    return true;
  });
}

export function isFilterActive(filter: BillFilter): boolean {
  return (
    filter.keyword.trim() !== "" ||
    filter.type !== "ALL" ||
    filter.categoryId !== "" ||
    filter.accountId !== "" ||
    filter.dateFrom !== "" ||
    filter.dateTo !== "" ||
    filter.amountMinYuan.trim() !== "" ||
    filter.amountMaxYuan.trim() !== ""
  );
}

export function validateTransaction(input: {
  type: Transaction["type"];
  amountFen: number;
  accountId?: string;
  categoryId?: string;
  fromAccountId?: string;
  toAccountId?: string;
}): string | null {
  if (!Number.isInteger(input.amountFen) || input.amountFen <= 0) {
    return "金额必须大于 0";
  }
  if (input.type === "TRANSFER") {
    if (!input.fromAccountId || !input.toAccountId) return "请选择转出和转入账户";
    if (input.fromAccountId === input.toAccountId) return "转出与转入不能相同";
    return null;
  }
  if (!input.accountId) return "请选择账户";
  if (!input.categoryId) return "请选择分类";
  return null;
}

export function findBudget(
  budgets: Budget[],
  month: string,
  categoryId: string | null,
): Budget | undefined {
  return budgets.find(
    (b) => b.status === "ACTIVE" && b.month === month && b.categoryId === categoryId,
  );
}
