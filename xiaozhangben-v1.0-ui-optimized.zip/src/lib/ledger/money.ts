/** All money is stored as integer fen (人民币分). Never persist floats. */

export function parseYuanInputToFen(input: string): number {
  const t = input.trim().replace(/,/g, "");
  if (!t || t === "." || t === "-" || t === "-.") return 0;
  const negative = t.startsWith("-");
  const s = negative ? t.slice(1) : t;
  const parts = s.split(".");
  if (parts.length > 2) return 0;
  const wholeRaw = parts[0] ?? "";
  const fracRaw = parts[1] ?? "";
  if (!/^\d*$/.test(wholeRaw) || !/^\d*$/.test(fracRaw)) return 0;
  const whole = wholeRaw === "" ? 0 : Number(wholeRaw);
  if (!Number.isSafeInteger(whole) || whole < 0) return 0;
  const frac = (fracRaw + "00").slice(0, 2);
  const fen = whole * 100 + Number(frac);
  if (!Number.isSafeInteger(fen)) return 0;
  return negative ? -fen : fen;
}

export function fenToYuanString(fen: number): string {
  const sign = fen < 0 ? "-" : "";
  const abs = Math.abs(Math.trunc(fen));
  const yuan = Math.floor(abs / 100);
  const cents = abs % 100;
  return `${sign}${yuan}.${cents.toString().padStart(2, "0")}`;
}

export function fenToInput(fen: number): string {
  const s = fenToYuanString(fen);
  if (s.endsWith(".00")) return s.slice(0, -3);
  if (s.endsWith("0") && s.includes(".")) return s.slice(0, -1);
  return s;
}

export function formatFen(
  fen: number,
  opts?: { sign?: boolean; symbol?: boolean; grouping?: boolean },
): string {
  const showSign = opts?.sign ?? false;
  const showSymbol = opts?.symbol ?? true;
  const grouping = opts?.grouping ?? true;
  const negative = fen < 0;
  const abs = Math.abs(Math.trunc(fen));
  const yuan = Math.floor(abs / 100);
  const cents = abs % 100;
  const whole = grouping ? yuan.toLocaleString("zh-CN") : String(yuan);
  const body = `${whole}.${cents.toString().padStart(2, "0")}`;
  const sign = negative ? "-" : showSign && fen > 0 ? "+" : "";
  const symbol = showSymbol ? "¥" : "";
  return `${sign}${symbol}${body}`;
}

export function appendAmountKey(current: string, key: string): string {
  if (key === "back") {
    if (current.length <= 1) return "";
    return current.slice(0, -1);
  }
  if (key === ".") {
    if (current.includes(".")) return current;
    return current === "" ? "0." : current + ".";
  }
  if (!/^\d$/.test(key)) return current;
  if (current === "0") return key;
  const [w, f] = current.split(".");
  if (f !== undefined && f.length >= 2) return current;
  if ((w ?? "").replace("-", "").length >= 8) return current;
  return current + key;
}

export function isValidPositiveAmount(input: string): boolean {
  return parseYuanInputToFen(input) > 0;
}
