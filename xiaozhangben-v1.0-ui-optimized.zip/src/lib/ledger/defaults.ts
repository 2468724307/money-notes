import { nid } from "./id";
import type { AccountType, AppSettings, Category } from "./types";

export const DEFAULT_SETTINGS: AppSettings = {
  bookName: "小账本",
  theme: "light",
  onboardingComplete: false,
  currency: "CNY",
};

export const ACCOUNT_TYPE_LABEL: Record<AccountType, string> = {
  CASH: "现金",
  BANK: "银行卡",
  WECHAT: "微信",
  ALIPAY: "支付宝",
  CUSTOM: "自定义",
};

export function defaultCategories(): Category[] {
  const expense: Array<[string, string]> = [
    ["餐饮", "utensils"],
    ["交通", "car"],
    ["购物", "shopping"],
    ["日用", "home"],
    ["娱乐", "film"],
    ["住房", "building"],
    ["医疗", "heart"],
    ["教育", "education"],
    ["通讯", "phone"],
    ["其他", "more"],
  ];
  const income: Array<[string, string]> = [
    ["工资", "wallet"],
    ["奖金", "award"],
    ["兼职", "briefcase"],
    ["理财", "trend"],
    ["红包", "gift"],
    ["其他", "coin"],
  ];
  const cats: Category[] = [];
  expense.forEach(([name, icon], i) => {
    cats.push({
      id: nid("cat"),
      name,
      type: "EXPENSE",
      icon,
      sortOrder: i,
      status: "ACTIVE",
    });
  });
  income.forEach(([name, icon], i) => {
    cats.push({
      id: nid("cat"),
      name,
      type: "INCOME",
      icon,
      sortOrder: i,
      status: "ACTIVE",
    });
  });
  return cats;
}

export const CATEGORY_ICON_KEYS = [
  "utensils",
  "car",
  "shopping",
  "home",
  "film",
  "building",
  "heart",
  "education",
  "phone",
  "more",
  "wallet",
  "award",
  "briefcase",
  "trend",
  "gift",
  "coin",
] as const;

export type CategoryIconKey = (typeof CATEGORY_ICON_KEYS)[number];
