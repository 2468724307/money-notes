export const SCHEMA_VERSION = 1 as const;

export type TransactionType = "EXPENSE" | "INCOME" | "TRANSFER";
export type AccountType = "CASH" | "BANK" | "WECHAT" | "ALIPAY" | "CUSTOM";
export type CategoryType = "EXPENSE" | "INCOME";
export type EntityStatus = "ACTIVE" | "INACTIVE";
export type ThemeMode = "light" | "dark" | "system";

export interface Transaction {
  id: string;
  type: TransactionType;
  amountFen: number;
  accountId?: string;
  categoryId?: string;
  fromAccountId?: string;
  toAccountId?: string;
  note: string;
  occurredAt: number;
  createdAt: number;
  updatedAt: number;
}

export interface Account {
  id: string;
  name: string;
  type: AccountType;
  openingBalanceFen: number;
  status: EntityStatus;
}

export interface Category {
  id: string;
  name: string;
  type: CategoryType;
  icon: string;
  sortOrder: number;
  status: EntityStatus;
}

export interface Budget {
  id: string;
  month: string;
  categoryId: string | null;
  amountFen: number;
  status: EntityStatus;
}

export interface AppSettings {
  bookName: string;
  theme: ThemeMode;
  onboardingComplete: boolean;
  lastUsedAccountId?: string;
  lastUsedExpenseCategoryId?: string;
  lastUsedIncomeCategoryId?: string;
  currency: "CNY";
}

export interface LedgerSnapshot {
  schemaVersion: typeof SCHEMA_VERSION;
  settings: AppSettings;
  accounts: Account[];
  categories: Category[];
  transactions: Transaction[];
  budgets: Budget[];
}

export interface BackupFile extends LedgerSnapshot {
  exportedAt: number;
  app: "xiaozhangben";
}

export interface BillFilter {
  keyword: string;
  type: TransactionType | "ALL";
  categoryId: string | "";
  accountId: string | "";
  dateFrom: string;
  dateTo: string;
  amountMinYuan: string;
  amountMaxYuan: string;
}

export const EMPTY_FILTER: BillFilter = {
  keyword: "",
  type: "ALL",
  categoryId: "",
  accountId: "",
  dateFrom: "",
  dateTo: "",
  amountMinYuan: "",
  amountMaxYuan: "",
};

export interface RecordDraft {
  type: TransactionType;
  editId?: string;
  amount: string;
  accountId: string;
  categoryId: string;
  fromAccountId: string;
  toAccountId: string;
  note: string;
  occurredAt: number;
}
