import { create } from "zustand";
import { EMPTY_FILTER, type BackupFile, type BillFilter, type CategoryType, type Transaction, type TransactionType } from "./types";
import { monthKey } from "./dates";

export type TabName = "home" | "bills" | "stats" | "me";

export type Screen =
  | { name: "welcome" }
  | { name: "setup" }
  | { name: TabName }
  | { name: "record"; type: TransactionType; editId?: string }
  | { name: "categories"; kind: CategoryType; pick?: boolean }
  | { name: "detail"; id: string }
  | { name: "filter" }
  | { name: "analysis"; categoryId: string }
  | { name: "budget" }
  | { name: "budget-edit"; categoryId: string | null }
  | { name: "accounts" }
  | { name: "account-edit"; id?: string }
  | { name: "data" }
  | { name: "import-preview" }
  | { name: "restore-preview" }
  | { name: "appearance" }
  | { name: "about" };

export interface ImportPreview {
  source: "json" | "csv";
  filename: string;
  transactions: Transaction[];
  errors: string[];
  backup?: BackupFile;
}

export interface RestorePreview {
  filename: string;
  backup: BackupFile;
}

interface NavState {
  tab: TabName;
  stack: Screen[];
  month: string;
  filter: BillFilter;
  fabOpen: boolean;
  importPreview: ImportPreview | null;
  restorePreview: RestorePreview | null;
  current: () => Screen;
  goTab: (tab: TabName) => void;
  push: (screen: Screen) => void;
  pop: () => void;
  replace: (screen: Screen) => void;
  resetTo: (screen: Screen) => void;
  setMonth: (month: string) => void;
  setFilter: (filter: BillFilter) => void;
  clearFilter: () => void;
  setFabOpen: (open: boolean) => void;
  setImportPreview: (p: ImportPreview | null) => void;
  setRestorePreview: (p: RestorePreview | null) => void;
}

export const useNavStore = create<NavState>((set, get) => ({
  tab: "home",
  stack: [],
  month: monthKey(),
  filter: { ...EMPTY_FILTER },
  fabOpen: false,
  importPreview: null,
  restorePreview: null,
  current: () => get().stack.at(-1) ?? { name: get().tab },
  goTab: (tab) => set({ tab, stack: [], fabOpen: false }),
  push: (screen) => set({ stack: [...get().stack, screen], fabOpen: false }),
  pop: () => set({ stack: get().stack.slice(0, -1), fabOpen: false }),
  replace: (screen) => {
    const stack = get().stack.slice();
    if (stack.length === 0) set({ stack: [screen] });
    else {
      stack[stack.length - 1] = screen;
      set({ stack });
    }
  },
  resetTo: (screen) => {
    if (screen.name === "home" || screen.name === "bills" || screen.name === "stats" || screen.name === "me") {
      set({ tab: screen.name, stack: [], fabOpen: false });
    } else {
      set({ stack: [screen], fabOpen: false });
    }
  },
  setMonth: (month) => set({ month }),
  setFilter: (filter) => set({ filter }),
  clearFilter: () => set({ filter: { ...EMPTY_FILTER } }),
  setFabOpen: (fabOpen) => set({ fabOpen }),
  setImportPreview: (importPreview) => set({ importPreview }),
  setRestorePreview: (restorePreview) => set({ restorePreview }),
}));

export function isTabScreen(screen: Screen): screen is { name: TabName } {
  return (
    screen.name === "home" ||
    screen.name === "bills" ||
    screen.name === "stats" ||
    screen.name === "me"
  );
}
