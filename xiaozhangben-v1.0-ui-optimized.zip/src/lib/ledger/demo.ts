import { nid } from "./id";
import { defaultCategories } from "./defaults";
import { monthKey } from "./dates";
import type { Account, Budget, LedgerSnapshot, Transaction } from "./types";
import { SCHEMA_VERSION } from "./types";

function at(year: number, monthIndex: number, day: number, hour = 12, minute = 8): number {
  return new Date(year, monthIndex, day, hour, minute, 0, 0).getTime();
}

export function buildDemoSnapshot(now = Date.now()): LedgerSnapshot {
  const d = new Date(now);
  const y = d.getFullYear();
  const m = d.getMonth();
  const month = monthKey(now);

  const cash: Account = {
    id: nid("acc"),
    name: "现金",
    type: "CASH",
    openingBalanceFen: 86_000,
    status: "ACTIVE",
  };
  const bank: Account = {
    id: nid("acc"),
    name: "招商银行",
    type: "BANK",
    openingBalanceFen: 1_560_000,
    status: "ACTIVE",
  };
  const alipay: Account = {
    id: nid("acc"),
    name: "支付宝",
    type: "ALIPAY",
    openingBalanceFen: 428_500,
    status: "ACTIVE",
  };
  const wechat: Account = {
    id: nid("acc"),
    name: "微信",
    type: "WECHAT",
    openingBalanceFen: 62_000,
    status: "ACTIVE",
  };

  const categories = defaultCategories();
  const cat = (name: string) => categories.find((c) => c.name === name)!.id;

  const stamp = (day: number, hour: number, minute = 10) => at(y, m, day, hour, minute);
  const prev = (day: number, hour = 12) => at(y, m - 1, day, hour, 20);

  const nowMs = Date.now();
  const mk = (
    partial: Omit<Transaction, "id" | "createdAt" | "updatedAt" | "note"> & { note?: string },
  ): Transaction => ({
    id: nid("tx"),
    note: partial.note ?? "",
    createdAt: nowMs,
    updatedAt: nowMs,
    ...partial,
  });

  const transactions: Transaction[] = [
    mk({
      type: "INCOME",
      amountFen: 18_600_00,
      accountId: bank.id,
      categoryId: cat("工资"),
      occurredAt: stamp(5, 9, 12),
      note: "九月工资",
    }),
    mk({
      type: "INCOME",
      amountFen: 80_000,
      accountId: alipay.id,
      categoryId: cat("兼职"),
      occurredAt: stamp(8, 21, 4),
      note: "周末设计稿",
    }),
    mk({
      type: "TRANSFER",
      amountFen: 200_000,
      fromAccountId: bank.id,
      toAccountId: alipay.id,
      occurredAt: stamp(5, 10, 1),
      note: "转入支付宝备用",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 2_800,
      accountId: alipay.id,
      categoryId: cat("餐饮"),
      occurredAt: stamp(1, 8, 20),
      note: "早饭",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 4_600,
      accountId: wechat.id,
      categoryId: cat("餐饮"),
      occurredAt: stamp(1, 12, 40),
      note: "午饭",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 1_500,
      accountId: alipay.id,
      categoryId: cat("交通"),
      occurredAt: stamp(2, 8, 5),
      note: "地铁",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 3_200,
      accountId: wechat.id,
      categoryId: cat("餐饮"),
      occurredAt: stamp(2, 18, 10),
      note: "咖啡",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 128_900,
      accountId: bank.id,
      categoryId: cat("购物"),
      occurredAt: stamp(3, 20, 18),
      note: "换季外套",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 6_800,
      accountId: alipay.id,
      categoryId: cat("日用"),
      occurredAt: stamp(4, 11, 2),
      note: "洗衣液",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 4_500,
      accountId: wechat.id,
      categoryId: cat("交通"),
      occurredAt: stamp(6, 19, 30),
      note: "打车回家",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 8_800,
      accountId: alipay.id,
      categoryId: cat("娱乐"),
      occurredAt: stamp(7, 20, 0),
      note: "电影两张",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 2_400_00,
      accountId: bank.id,
      categoryId: cat("住房"),
      occurredAt: stamp(8, 10, 0),
      note: "房租",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 5_600,
      accountId: alipay.id,
      categoryId: cat("餐饮"),
      occurredAt: stamp(9, 13, 12),
      note: "午饭",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 12_800,
      accountId: wechat.id,
      categoryId: cat("通讯"),
      occurredAt: stamp(10, 9, 40),
      note: "话费",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 3_900,
      accountId: cash.id,
      categoryId: cat("日用"),
      occurredAt: stamp(11, 16, 22),
      note: "菜市场",
    }),
    mk({
      type: "INCOME",
      amountFen: 6_600,
      accountId: wechat.id,
      categoryId: cat("红包"),
      occurredAt: stamp(11, 21, 8),
      note: "同事红包",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 18_600,
      accountId: alipay.id,
      categoryId: cat("医疗"),
      occurredAt: stamp(Math.min(d.getDate(), 12), 15, 4),
      note: "药店",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 7_200,
      accountId: alipay.id,
      categoryId: cat("餐饮"),
      occurredAt: stamp(Math.min(d.getDate(), 12), 19, 40),
      note: "晚饭",
    }),
    mk({
      type: "INCOME",
      amountFen: 18_200_00,
      accountId: bank.id,
      categoryId: cat("工资"),
      occurredAt: prev(5, 9),
      note: "八月工资",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 2_400_00,
      accountId: bank.id,
      categoryId: cat("住房"),
      occurredAt: prev(8, 10),
      note: "房租",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 96_000,
      accountId: alipay.id,
      categoryId: cat("餐饮"),
      occurredAt: prev(18, 13),
      note: "聚餐",
    }),
    mk({
      type: "EXPENSE",
      amountFen: 32_000,
      accountId: wechat.id,
      categoryId: cat("交通"),
      occurredAt: prev(20, 8),
      note: "月票",
    }),
  ].sort((a, b) => b.occurredAt - a.occurredAt);

  const budgets: Budget[] = [
    {
      id: nid("bud"),
      month,
      categoryId: null,
      amountFen: 600_000,
      status: "ACTIVE",
    },
    {
      id: nid("bud"),
      month,
      categoryId: cat("餐饮"),
      amountFen: 150_000,
      status: "ACTIVE",
    },
    {
      id: nid("bud"),
      month,
      categoryId: cat("交通"),
      amountFen: 40_000,
      status: "ACTIVE",
    },
  ];

  return {
    schemaVersion: SCHEMA_VERSION,
    settings: {
      bookName: "小账本",
      theme: "light",
      onboardingComplete: true,
      lastUsedAccountId: alipay.id,
      lastUsedExpenseCategoryId: cat("餐饮"),
      lastUsedIncomeCategoryId: cat("工资"),
      currency: "CNY",
    },
    accounts: [cash, bank, alipay, wechat],
    categories,
    transactions,
    budgets,
  };
}
