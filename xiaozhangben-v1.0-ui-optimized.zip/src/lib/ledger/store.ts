import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { SCHEMA_VERSION, type Account, type AccountType, type AppSettings, type BackupFile, type Budget, type Category, type CategoryType, type LedgerSnapshot, type Transaction } from "./types";
import { DEFAULT_SETTINGS, defaultCategories } from "./defaults";
import { nid } from "./id";
import { validateTransaction } from "./formulas";
import { buildDemoSnapshot } from "./demo";

export interface LedgerState extends LedgerSnapshot {
  addTransaction: (input: Omit<Transaction, "id" | "createdAt" | "updatedAt">) => string;
  updateTransaction: (id: string, patch: Partial<Omit<Transaction, "id" | "createdAt">>) => void;
  deleteTransaction: (id: string) => void;
  addAccount: (input: { name: string; type: AccountType; openingBalanceFen: number }) => string;
  updateAccount: (id: string, patch: Partial<Pick<Account, "name" | "type" | "openingBalanceFen">>) => void;
  deactivateAccount: (id: string) => void;
  addCategory: (input: { name: string; type: CategoryType; icon: string }) => string;
  updateCategory: (id: string, patch: Partial<Pick<Category, "name" | "icon">>) => void;
  deactivateCategory: (id: string) => void;
  moveCategory: (id: string, dir: -1 | 1) => void;
  upsertBudget: (input: { month: string; categoryId: string | null; amountFen: number }) => void;
  deleteBudget: (id: string) => void;
  completeSetup: (input: {
    bookName: string;
    accountName: string;
    accountType: AccountType;
    openingBalanceFen: number;
  }) => void;
  loadDemo: () => void;
  patchSettings: (patch: Partial<AppSettings>) => void;
  importTransactions: (rows: Transaction[]) => void;
  restoreBackup: (file: BackupFile) => void;
  replaceAll: (snap: LedgerSnapshot) => void;
  resetLocalData: () => void;
}

function sortTx(list: Transaction[]): Transaction[] {
  return list.slice().sort((a, b) => b.occurredAt - a.occurredAt || b.createdAt - a.createdAt);
}

const emptySnap = (): LedgerSnapshot => ({
  schemaVersion: SCHEMA_VERSION,
  settings: { ...DEFAULT_SETTINGS },
  accounts: [],
  categories: [],
  transactions: [],
  budgets: [],
});

export const useLedgerStore = create<LedgerState>()(
  persist(
    (set, get) => ({
      ...emptySnap(),

      addTransaction: (input) => {
        const err = validateTransaction(input);
        if (err) throw new Error(err);
        const now = Date.now();
        const tx: Transaction = {
          ...input,
          note: input.note ?? "",
          id: nid("tx"),
          createdAt: now,
          updatedAt: now,
        };
        const settings = { ...get().settings };
        if (tx.accountId) settings.lastUsedAccountId = tx.accountId;
        if (tx.type === "EXPENSE" && tx.categoryId) settings.lastUsedExpenseCategoryId = tx.categoryId;
        if (tx.type === "INCOME" && tx.categoryId) settings.lastUsedIncomeCategoryId = tx.categoryId;
        set({ transactions: sortTx([tx, ...get().transactions]), settings });
        return tx.id;
      },

      updateTransaction: (id, patch) => {
        const prev = get().transactions.find((t) => t.id === id);
        if (!prev) throw new Error("找不到这笔账单");
        const next = { ...prev, ...patch, id, createdAt: prev.createdAt, updatedAt: Date.now() };
        const err = validateTransaction(next);
        if (err) throw new Error(err);
        set({
          transactions: sortTx(get().transactions.map((t) => (t.id === id ? next : t))),
        });
      },

      deleteTransaction: (id) => {
        set({ transactions: get().transactions.filter((t) => t.id !== id) });
      },

      addAccount: ({ name, type, openingBalanceFen }) => {
        const acc: Account = {
          id: nid("acc"),
          name: name.trim() || "未命名账户",
          type,
          openingBalanceFen,
          status: "ACTIVE",
        };
        set({ accounts: [...get().accounts, acc] });
        return acc.id;
      },

      updateAccount: (id, patch) => {
        set({
          accounts: get().accounts.map((a) =>
            a.id === id
              ? {
                  ...a,
                  ...patch,
                  name: patch.name !== undefined ? patch.name.trim() || a.name : a.name,
                }
              : a,
          ),
        });
      },

      deactivateAccount: (id) => {
        const active = get().accounts.filter((a) => a.status === "ACTIVE");
        if (active.length <= 1 && active[0]?.id === id) {
          throw new Error("至少保留一个可用账户");
        }
        const used = get().transactions.some(
          (t) => t.accountId === id || t.fromAccountId === id || t.toAccountId === id,
        );
        if (used) {
          set({
            accounts: get().accounts.map((a) => (a.id === id ? { ...a, status: "INACTIVE" } : a)),
          });
        } else {
          set({ accounts: get().accounts.filter((a) => a.id !== id) });
        }
      },

      addCategory: ({ name, type, icon }) => {
        const list = get().categories.filter((c) => c.type === type);
        const cat: Category = {
          id: nid("cat"),
          name: name.trim() || "未命名",
          type,
          icon,
          sortOrder: list.length,
          status: "ACTIVE",
        };
        set({ categories: [...get().categories, cat] });
        return cat.id;
      },

      updateCategory: (id, patch) => {
        set({
          categories: get().categories.map((c) =>
            c.id === id
              ? { ...c, ...patch, name: patch.name !== undefined ? patch.name.trim() || c.name : c.name }
              : c,
          ),
        });
      },

      deactivateCategory: (id) => {
        const used = get().transactions.some((t) => t.categoryId === id);
        if (used) {
          set({
            categories: get().categories.map((c) => (c.id === id ? { ...c, status: "INACTIVE" } : c)),
          });
        } else {
          set({ categories: get().categories.filter((c) => c.id !== id) });
        }
      },

      moveCategory: (id, dir) => {
        const all = get().categories.slice();
        const target = all.find((c) => c.id === id);
        if (!target) return;
        const group = all
          .filter((c) => c.type === target.type && c.status === "ACTIVE")
          .sort((a, b) => a.sortOrder - b.sortOrder);
        const idx = group.findIndex((c) => c.id === id);
        const swap = group[idx + dir];
        if (!swap) return;
        const a = target.sortOrder;
        target.sortOrder = swap.sortOrder;
        swap.sortOrder = a;
        set({ categories: all.map((c) => (c.id === target.id ? target : c.id === swap.id ? swap : c)) });
      },

      upsertBudget: ({ month, categoryId, amountFen }) => {
        if (amountFen <= 0) throw new Error("预算金额必须大于 0");
        const existing = get().budgets.find(
          (b) => b.month === month && b.categoryId === categoryId && b.status === "ACTIVE",
        );
        if (existing) {
          set({
            budgets: get().budgets.map((b) => (b.id === existing.id ? { ...b, amountFen } : b)),
          });
        } else {
          const bud: Budget = {
            id: nid("bud"),
            month,
            categoryId,
            amountFen,
            status: "ACTIVE",
          };
          set({ budgets: [...get().budgets, bud] });
        }
      },

      deleteBudget: (id) => {
        set({ budgets: get().budgets.filter((b) => b.id !== id) });
      },

      completeSetup: ({ bookName, accountName, accountType, openingBalanceFen }) => {
        const acc: Account = {
          id: nid("acc"),
          name: accountName.trim() || "现金",
          type: accountType,
          openingBalanceFen,
          status: "ACTIVE",
        };
        set({
          settings: {
            ...get().settings,
            bookName: bookName.trim() || "小账本",
            onboardingComplete: true,
            lastUsedAccountId: acc.id,
          },
          accounts: [acc],
          categories: defaultCategories(),
          transactions: [],
          budgets: [],
        });
      },

      loadDemo: () => {
        const demo = buildDemoSnapshot();
        set({ ...demo });
      },

      patchSettings: (patch) => {
        set({ settings: { ...get().settings, ...patch } });
      },

      importTransactions: (rows) => {
        if (!rows.length) return;
        set({ transactions: sortTx([...rows, ...get().transactions]) });
      },

      restoreBackup: (file) => {
        set({
          schemaVersion: SCHEMA_VERSION,
          settings: { ...file.settings, onboardingComplete: true },
          accounts: file.accounts,
          categories: file.categories,
          transactions: sortTx(file.transactions),
          budgets: file.budgets ?? [],
        });
      },

      replaceAll: (snap) => {
        set({
          schemaVersion: SCHEMA_VERSION,
          settings: snap.settings,
          accounts: snap.accounts,
          categories: snap.categories,
          transactions: sortTx(snap.transactions),
          budgets: snap.budgets,
        });
      },

      resetLocalData: () => set(emptySnap()),
    }),
    {
      name: "xiaozhangben.v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({
        schemaVersion: s.schemaVersion,
        settings: s.settings,
        accounts: s.accounts,
        categories: s.categories,
        transactions: s.transactions,
        budgets: s.budgets,
      }),
    },
  ),
);

export function snapshotFromStore(): LedgerSnapshot {
  const s = useLedgerStore.getState();
  return {
    schemaVersion: s.schemaVersion,
    settings: s.settings,
    accounts: s.accounts,
    categories: s.categories,
    transactions: s.transactions,
    budgets: s.budgets,
  };
}
