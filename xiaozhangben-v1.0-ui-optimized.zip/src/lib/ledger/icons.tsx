import type { LucideIcon } from "lucide-react";
import {
  Award,
  Briefcase,
  Building2,
  Car,
  CircleDollarSign,
  Clapperboard,
  CreditCard,
  Ellipsis,
  Gift,
  GraduationCap,
  HeartPulse,
  House,
  Landmark,
  MessageCircle,
  ShoppingBag,
  Smartphone,
  TrendingUp,
  UtensilsCrossed,
  Wallet,
  Banknote,
} from "lucide-react";
import type { AccountType } from "./types";

export const CATEGORY_ICONS: Record<string, LucideIcon> = {
  utensils: UtensilsCrossed,
  car: Car,
  shopping: ShoppingBag,
  home: House,
  film: Clapperboard,
  building: Building2,
  heart: HeartPulse,
  education: GraduationCap,
  phone: Smartphone,
  more: Ellipsis,
  wallet: Wallet,
  award: Award,
  briefcase: Briefcase,
  trend: TrendingUp,
  gift: Gift,
  coin: CircleDollarSign,
};

export function categoryIcon(key: string): LucideIcon {
  return CATEGORY_ICONS[key] ?? Ellipsis;
}

export const ACCOUNT_ICONS: Record<AccountType, LucideIcon> = {
  CASH: Banknote,
  BANK: CreditCard,
  WECHAT: MessageCircle,
  ALIPAY: Wallet,
  CUSTOM: Landmark,
};
