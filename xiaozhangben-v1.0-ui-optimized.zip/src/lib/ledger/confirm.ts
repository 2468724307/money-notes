import { create } from "zustand";

export interface ConfirmOptions {
  title: string;
  body: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
}

interface ConfirmState extends ConfirmOptions {
  open: boolean;
  resolve: ((ok: boolean) => void) | null;
  ask: (opts: ConfirmOptions) => Promise<boolean>;
  close: (ok: boolean) => void;
}

export const useConfirmStore = create<ConfirmState>((set, get) => ({
  open: false,
  title: "",
  body: "",
  confirmLabel: "确定",
  cancelLabel: "取消",
  danger: false,
  resolve: null,
  ask: (opts) =>
    new Promise<boolean>((resolve) => {
      get().resolve?.(false);
      set({
        open: true,
        title: opts.title,
        body: opts.body,
        confirmLabel: opts.confirmLabel ?? "确定",
        cancelLabel: opts.cancelLabel ?? "取消",
        danger: opts.danger ?? false,
        resolve,
      });
    }),
  close: (ok) => {
    const { resolve } = get();
    set({ open: false, resolve: null });
    resolve?.(ok);
  },
}));

export function confirmAction(opts: ConfirmOptions): Promise<boolean> {
  return useConfirmStore.getState().ask(opts);
}
