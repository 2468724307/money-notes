import { SCHEMA_VERSION, type BackupFile, type LedgerSnapshot, type Transaction } from "./types";
import { fenToYuanString } from "./money";
import { formatDateTime } from "./dates";
import { ACCOUNT_TYPE_LABEL } from "./defaults";

export function snapshotToBackup(snap: LedgerSnapshot, exportedAt = Date.now()): BackupFile {
  return {
    app: "xiaozhangben",
    schemaVersion: SCHEMA_VERSION,
    exportedAt,
    settings: snap.settings,
    accounts: snap.accounts,
    categories: snap.categories,
    transactions: snap.transactions,
    budgets: snap.budgets,
  };
}

export function parseBackupJson(text: string): BackupFile {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    throw new Error("无法解析 JSON 文件");
  }
  if (!raw || typeof raw !== "object") throw new Error("备份文件格式无效");
  const obj = raw as Record<string, unknown>;
  if (obj.app && obj.app !== "xiaozhangben") {
    throw new Error("这不是小账本的备份文件");
  }
  const version = Number(obj.schemaVersion ?? obj.schema_version ?? 1);
  if (version !== SCHEMA_VERSION) {
    throw new Error(`不支持的备份版本（${version}）`);
  }
  if (!Array.isArray(obj.accounts) || !Array.isArray(obj.transactions) || !Array.isArray(obj.categories)) {
    throw new Error("备份缺少必要数据");
  }
  return {
    app: "xiaozhangben",
    schemaVersion: SCHEMA_VERSION,
    exportedAt: Number(obj.exportedAt ?? obj.exported_at ?? Date.now()),
    settings: (obj.settings as BackupFile["settings"]) ?? {
      bookName: "小账本",
      theme: "light",
      onboardingComplete: true,
      currency: "CNY",
    },
    accounts: obj.accounts as BackupFile["accounts"],
    categories: obj.categories as BackupFile["categories"],
    transactions: obj.transactions as BackupFile["transactions"],
    budgets: Array.isArray(obj.budgets) ? (obj.budgets as BackupFile["budgets"]) : [],
  };
}

export function snapshotToCsv(snap: LedgerSnapshot): string {
  const header = [
    "id",
    "type",
    "amount_yuan",
    "account",
    "from_account",
    "to_account",
    "category",
    "note",
    "occurred_at",
  ];
  const accName = (id?: string) => snap.accounts.find((a) => a.id === id)?.name ?? "";
  const catName = (id?: string) => snap.categories.find((c) => c.id === id)?.name ?? "";
  const lines = snap.transactions
    .slice()
    .sort((a, b) => b.occurredAt - a.occurredAt)
    .map((tx) =>
      [
        tx.id,
        tx.type,
        fenToYuanString(tx.amountFen),
        csvCell(accName(tx.accountId)),
        csvCell(accName(tx.fromAccountId)),
        csvCell(accName(tx.toAccountId)),
        csvCell(catName(tx.categoryId)),
        csvCell(tx.note),
        formatDateTime(tx.occurredAt),
      ].join(","),
    );
  return [header.join(","), ...lines].join("\n");
}

function csvCell(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

export function parseCsvTransactions(
  text: string,
  snap: LedgerSnapshot,
): { rows: Transaction[]; errors: string[] } {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) throw new Error("CSV 没有数据行");
  const header = splitCsvLine(lines[0]!).map((h) => h.trim().toLowerCase());
  const idx = (name: string) => header.indexOf(name);
  const iType = idx("type");
  const iAmount = idx("amount_yuan") >= 0 ? idx("amount_yuan") : idx("amount");
  const iAccount = idx("account");
  const iFrom = idx("from_account");
  const iTo = idx("to_account");
  const iCat = idx("category");
  const iNote = idx("note");
  const iTime = idx("occurred_at");
  if (iType < 0 || iAmount < 0) throw new Error("CSV 缺少 type 或 amount 列");

  const errors: string[] = [];
  const rows: Transaction[] = [];
  const now = Date.now();

  for (let n = 1; n < lines.length; n++) {
    const cols = splitCsvLine(lines[n]!);
    const type = (cols[iType] ?? "").trim().toUpperCase();
    if (type !== "EXPENSE" && type !== "INCOME" && type !== "TRANSFER") {
      errors.push(`第 ${n + 1} 行：未知类型 ${type}`);
      continue;
    }
    const amountYuan = (cols[iAmount] ?? "").trim();
    const fen = Math.round(Number(amountYuan) * 100);
    if (!Number.isFinite(fen) || fen <= 0) {
      errors.push(`第 ${n + 1} 行：金额无效`);
      continue;
    }
    const findAcc = (name: string) =>
      snap.accounts.find((a) => a.name === name && a.status === "ACTIVE");
    const findCat = (name: string) =>
      snap.categories.find((c) => c.name === name && c.type === (type === "INCOME" ? "INCOME" : "EXPENSE"));

    const occurredAt = iTime >= 0 ? Date.parse(cols[iTime] ?? "") : now;
    const tx: Transaction = {
      id: `imp_${n}_${now}`,
      type,
      amountFen: fen,
      note: iNote >= 0 ? (cols[iNote] ?? "") : "",
      occurredAt: Number.isFinite(occurredAt) ? occurredAt : now,
      createdAt: now,
      updatedAt: now,
    };
    if (type === "TRANSFER") {
      const from = findAcc((cols[iFrom] ?? "").trim());
      const to = findAcc((cols[iTo] ?? "").trim());
      if (!from || !to) {
        errors.push(`第 ${n + 1} 行：转账账户未匹配`);
        continue;
      }
      tx.fromAccountId = from.id;
      tx.toAccountId = to.id;
    } else {
      const acc = findAcc((cols[iAccount] ?? "").trim());
      const cat = findCat((cols[iCat] ?? "").trim());
      if (!acc) {
        errors.push(`第 ${n + 1} 行：账户未匹配`);
        continue;
      }
      tx.accountId = acc.id;
      if (cat) tx.categoryId = cat.id;
    }
    rows.push(tx);
  }
  return { rows, errors };
}

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]!;
    if (q) {
      if (ch === '"' && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (ch === '"') {
        q = false;
      } else {
        cur += ch;
      }
    } else if (ch === '"') {
      q = true;
    } else if (ch === ",") {
      out.push(cur);
      cur = "";
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

export function downloadText(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function pickLocalFile(accept: string): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = accept;
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.click();
  });
}

export function accountTypeLabel(type: string): string {
  return ACCOUNT_TYPE_LABEL[type as keyof typeof ACCOUNT_TYPE_LABEL] ?? type;
}
